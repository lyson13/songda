-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 05, 2017 at 06:05 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `songda`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `parent` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `slug` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `description`, `parent`, `position`, `status`, `slug`) VALUES
(1, 'Giới thiệu', '', 0, 1, 1, 'gioi-thieu'),
(2, 'Tin tức', '', 0, 3, 1, 'tin-tuc'),
(3, 'Công trình dự án', '', 0, 2, 1, 'cong-trinh-du-an'),
(4, 'Tuyển dụng', '', 0, 4, 1, 'tuyen-dung'),
(5, 'Dự án đầu tư', '', 3, 0, 1, 'du-an-dau-tu'),
(6, 'Công trình thi công', '', 3, 0, 1, 'cong-trinh-thi-cong'),
(7, 'Quan hệ cổ đông', '', 2, 0, 1, 'quan-he-co-dong'),
(8, 'Thông tin tài chính', '', 2, 0, 1, 'thong-tin-tai-chinh'),
(9, 'Thông tin tổng công ty sông đà', '', 2, 0, 1, 'thong-tin-tong-cong-ty-song-da'),
(10, 'Đảng-Công đoàn-Đoàn thanh niên', '', 2, 0, 1, 'dang-cong-doan-doan-thanh-nien'),
(11, 'Lĩnh vực kinh doanh', '', 1, 0, 1, 'linh-vuc-kinh-doanh'),
(13, 'Trang chủ', '', 0, 0, 1, 'trang-chu'),
(14, 'Liên hệ', '', 0, 7, 1, 'lien-he'),
(15, 'Công trình dự án đang thi công', '', 3, 4, 1, 'cong-trinh-du-an-dang-thi-cong'),
(16, 'Công trình dự án đã thi công', '', 3, 4, 1, 'cong-trinh-du-an-da-thi-cong'),
(17, 'Công trình thủy điện', '', 5, 0, 1, 'cong-trinh-thuy-dien'),
(18, 'test 1', '', 1, 0, 0, 'test-1'),
(19, 'test 2', '', 0, 0, 0, 'test-2');

-- --------------------------------------------------------

--
-- Table structure for table `category_news_details`
--

CREATE TABLE `category_news_details` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `news_id` int(11) NOT NULL,
  `note` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category_news_details`
--

INSERT INTO `category_news_details` (`id`, `category_id`, `news_id`, `note`) VALUES
(12, 2, 30, ''),
(13, 2, 31, ''),
(14, 2, 32, ''),
(15, 2, 33, ''),
(16, 2, 34, ''),
(17, 2, 35, ''),
(18, 4, 35, ''),
(19, 4, 36, ''),
(20, 4, 37, ''),
(21, 4, 38, ''),
(22, 4, 39, ''),
(23, 4, 40, ''),
(24, 5, 41, ''),
(25, 6, 41, ''),
(26, 3, 42, ''),
(27, 5, 42, ''),
(28, 3, 43, ''),
(29, 6, 43, ''),
(30, 3, 44, ''),
(31, 6, 44, ''),
(32, 3, 45, ''),
(33, 6, 45, ''),
(34, 3, 46, ''),
(35, 6, 46, ''),
(36, 3, 48, ''),
(37, 6, 48, ''),
(38, 3, 49, ''),
(39, 6, 49, ''),
(40, 1, 50, ''),
(41, 1, 51, ''),
(42, 1, 52, ''),
(43, 1, 53, ''),
(44, 11, 53, ''),
(45, 1, 54, ''),
(46, 11, 54, ''),
(48, 11, 56, ''),
(49, 11, 55, '');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `address` varchar(500) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `title` varchar(500) NOT NULL,
  `content` text NOT NULL,
  `date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `address`, `tel`, `title`, `content`, `date`) VALUES
(1, '121', '121', '1231237777', '123', '12', '2017/05/30 09:39:21');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_10_12_000000_create_users_table', 1),
('2014_10_12_100000_create_password_resets_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `description` text NOT NULL,
  `content` text NOT NULL,
  `images` varchar(255) NOT NULL,
  `posted_date` varchar(50) NOT NULL,
  `hot` int(11) NOT NULL,
  `view` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `slug` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `description`, `content`, `images`, `posted_date`, `hot`, `view`, `status`, `slug`) VALUES
(30, 'Giấy ủy quyền thực hiện công bố thông tin', '<p>Giấy ủy quyền thực hiện c&ocirc;ng bố th&ocirc;ng tin</p>\r\n', '<h2>Giấy ủy quyền thực hiện c&ocirc;ng bố th&ocirc;ng tin</h2>\r\n\r\n<p>Giấy ủy quyền thực hiện c&ocirc;ng bố th&ocirc;ng tin c&ocirc;ng ty cổ phần S&ocirc;ng Đ&agrave; 6 Download&nbsp;<a href="http://songda6.com.vn/editor/elfinder/files/BAO%20CAO%20TAI%20CHINH/NAM%202017/uyquyencbtt.pdf">Tại đ&acirc;y</a></p>\r\n', '00s23m23h-03062017-small_anh71493365063.jpg', '2017-06-03', 0, 0, 1, 'giay-uy-quyen-thuc-hien-cong-bo-thong-tin'),
(31, 'Quyết định v/v Bổ nhiệm chức vụ Phó Tổng giám đốc Công ty - ông Nguyễn Minh Tuấn', '<p>Quyết định v/v Bổ nhiệm chức vụ Ph&oacute; Tổng gi&aacute;m đốc C&ocirc;ng ty - &ocirc;ng Nguyễn Minh Tuấn</p>\r\n', '<p>Quyết định v/v Bổ nhiệm chức vụ Ph&oacute; Tổng gi&aacute;m đốc C&ocirc;ng ty - &ocirc;ng Nguyễn Minh Tuấn Download&nbsp;<a href="http://songda6.com.vn/editor/elfinder/files/NGHI%20QUYET%20HOI%20DONG%20QUAN%20TRI%20NAM%202015/2017/50%20QD%20HDQT.pdf">Tại đ&acirc;y</a></p>\r\n', '10s24m23h-03062017-small_031494052361.jpg', '2017-06-03', 0, 0, 1, 'quyet-dinh-vv-bo-nhiem-chuc-vu-pho-tong-giam-doc-cong-ty-ong-nguyen-minh-tuan'),
(32, 'Công bố thay đổi số lượng cổ phiếu đang lưu hành', '<p>C&ocirc;ng bố thay đổi số lượng cổ phiếu đang lưu h&agrave;nh</p>\r\n', '<h2>Thay đổi số lượng cổ phiếu đang lưu h&agrave;nh</h2>\r\n\r\n<p>Thay đổi cổ phiếu đang lưu h&agrave;nh Download&nbsp;<a href="http://www.songda6.com.vn/home/uploadedFiles/236.pdf">tại đ&acirc;y</a></p>\r\n', '', '2017-06-03', 0, 0, 1, 'cong-bo-thay-doi-so-luong-co-phieu-dang-luu-hanh'),
(33, 'Biên bản; Nghị quyết Đại hội; Nghị quyết Đại hội chào bán cổ phiếu riêng lẻ', '<p>Bi&ecirc;n bản; Nghị quyết Đại hội; Nghị quyết Đại hội ch&agrave;o b&aacute;n cổ phiếu ri&ecirc;ng lẻ</p>\r\n', '<h2>Bi&ecirc;n bản họp Đại hội đồng cổ đ&ocirc;ng thường ni&ecirc;n C&ocirc;ng ty năm 2014;<br />\r\nNghị Quyết Đại hội đồng cổ đ&ocirc;ng thường ni&ecirc;n C&ocirc;ng ty Năm 2014;<br />\r\nNghị quyết Đại hội th&ocirc;ng qua kết quả ph&aacute;t h&agrave;nh ch&agrave;o b&aacute;n cổ phiếu ri&ecirc;ng lẻ&nbsp;</h2>\r\n\r\n<p>Bi&ecirc;n bản họp được Download&nbsp;<a href="http://www.songda6.com.vn/home/uploadedFiles/59bbdhdcd-2.pdf">Tại đ&acirc;y</a><br />\r\nNghị Quyết Đại Hội được download&nbsp;<a href="http://songda6.com.vn/editor/elfinder/files/DAI%20HOI%20DONG%20CO%20DONG/60%20NQ%20DHDCD%20nam%202014.pdf">Tại đ&acirc;y</a><br />\r\nNghị quyết th&ocirc;ng qua kết quả ph&aacute;t h&agrave;nh ch&agrave;o b&aacute;n cổ phiếu ri&ecirc;ng lẻ Download&nbsp;<a href="http://www.songda6.com.vn/home/uploadedFiles/61nqhdqt-1.pdf">Tại đ&acirc;y</a></p>\r\n', '', '2017-06-03', 0, 0, 1, 'bien-ban-nghi-quyet-dai-hoi-nghi-quyet-dai-hoi-chao-ban-co-phieu-rieng-le'),
(34, 'Bổ nhiệm giữ chức vụ Kế toán trưởng Công ty cổ phần Sông Đà 6', '<p>Bổ nhiệm giữ chức vụ Kế to&aacute;n trưởng C&ocirc;ng ty cổ phần S&ocirc;ng Đ&agrave; 6</p>\r\n', '<h2>Bổ nhiệm giữ chức vụ Kế to&aacute;n trưởng C&ocirc;ng ty cổ phần S&ocirc;ng Đ&agrave; 6</h2>\r\n\r\n<p>Bổ nhiệm giữ chức vụ Kế to&aacute;n trưởng C&ocirc;ng ty cổ phần S&ocirc;ng Đ&agrave; 6 Download&nbsp;<a href="http://www.songda6.com.vn/home/uploadedFiles/39%20QD%20HDQT%20bo%20nhiem%20KTT%20Le%20Van%20Sinh.pdf">Tại đ&acirc;y</a></p>\r\n', '', '2017-06-03', 0, 0, 0, 'bo-nhiem-giu-chuc-vu-ke-toan-truong-cong-ty-co-phan-song-da-6'),
(35, 'Tuyển dụng nhân viên kỹ thuật - 01 người', '<p>Vị tr&iacute; tuyển dụng: Nh&acirc;n vi&ecirc;n kỹ thuật (số lượng 01 người).</p>\r\n', '<h2>Vị tr&iacute; tuyển dụng: Nh&acirc;n vi&ecirc;n kỹ thuật (số lượng 01 người).</h2>\r\n\r\n<table style="width:705px">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n			<p><strong>C&Ocirc;NG TY CỔ PHẦN S&Ocirc;NG Đ&Agrave; 6</strong></p>\r\n\r\n			<p>Nh&agrave; TM - Khu đ&ocirc; thị Văn Kh&ecirc; - Phường La Kh&ecirc; - Quận H&agrave; Đ&ocirc;ng - TP H&agrave; Nội</p>\r\n\r\n			<p><strong>Điện thoại:&nbsp;</strong>(+84-4) 22169622 - Fax (+84-4) 22253366</p>\r\n\r\n			<p><strong>Email:&nbsp;</strong>congtycophansongda6@songda6.com.vn</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>&nbsp;</strong></p>\r\n\r\n<p><strong>TH&Ocirc;NG B&Aacute;O TUYỂN DỤNG</strong></p>\r\n\r\n<p><strong>C&Ocirc;NG TY CỔ PHẦN S&Ocirc;NG Đ&Agrave; 6</strong></p>\r\n\r\n<p>Hiện nay c&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6 c&oacute; nhu cầu tuyển dụng như sau:</p>\r\n\r\n<ol>\r\n	<li><strong>Vị tr&iacute; tuyển dụng: Nh&acirc;n vi&ecirc;n kỹ thuật (Số lượng: 01)</strong></li>\r\n	<li><strong>Địa điểm l&agrave;m việc:&nbsp;</strong>Ph&ograve;ng Kỹ thuật &ndash; C&ocirc;ng nghệ, C&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6 (H&agrave; Nội)</li>\r\n	<li><strong>Mức lương tuyển dụng: Theo thỏa thuận</strong></li>\r\n	<li><strong>Ti&ecirc;u chuẩn tuyển dụng</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Tốt nghiệp đại học chuy&ecirc;n ng&agrave;nh: Thủy lợi &ndash; Thủy điện; X&acirc;y dựng&hellip;</li>\r\n	<li>Ưu ti&ecirc;n c&aacute;c ứng vi&ecirc;n c&oacute; tr&igrave;nh độ Thạc sỹ</li>\r\n	<li>Tiếng Anh đạt tr&igrave;nh độ B2 theo chuẩn Ch&acirc;u &Acirc;u (c&oacute; phỏng vấn v&agrave; kiểm tra tr&igrave;nh độ thực tế)</li>\r\n	<li>C&oacute; kinh nghiệm tối thiểu 05 năm l&agrave;m việc trong lĩnh vực x&acirc;y dựng. Ưu ti&ecirc;n ứng vi&ecirc;n c&oacute; kinh nghiệm l&agrave;m việc trong lĩnh vực tư vấn thiết kế v&agrave; quản l&yacute; dự &aacute;n</li>\r\n	<li>Sử dụng được c&aacute;c phần mềm văn ph&ograve;ng cơ bản, c&aacute;c phần mềm chuy&ecirc;n ng&agrave;nh như AutoCad 3D, Revit, c&aacute;c phần mềm quản l&yacute; tiến độ&hellip;</li>\r\n	<li>Y&ecirc;u cầu c&oacute; khả năng giao tiếp tốt, kỹ năng đ&agrave;m ph&aacute;n, thuyết tr&igrave;nh, phối hợp v&agrave; l&agrave;m việc theo nh&oacute;m tốt, kỹ năng quản l&yacute; thời gian, sắp xếp giải quyết c&ocirc;ng việc hiệu quả, chịu được cường độ l&agrave;m việc cao, c&oacute; &yacute; thức kỷ luật v&agrave; tr&aacute;ch nhiệm cao với c&ocirc;ng việc.</li>\r\n</ul>\r\n\r\n<ol start="5">\r\n	<li><strong>C&aacute;c chế độ đ&atilde;i ngộ v&agrave; ph&uacute;c lợi</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>C&oacute; chế độ đ&atilde;i ngộ, ph&uacute;c lợi tốt với c&aacute;c ng&agrave;y nghỉ, Lễ, Tết, mức thưởng theo năng suất l&agrave;m việc v&agrave; kết quả sản xuất kinh doanh.</li>\r\n	<li>Được đ&agrave;o tạo n&acirc;ng cao về chuy&ecirc;n m&ocirc;n v&agrave; kỹ năng quản l&yacute; trong nước v&agrave; nước ngo&agrave;i.</li>\r\n	<li>Khả năng thăng tiến cao, c&oacute; cơ hội được lựa chọn v&agrave; đ&agrave;o tạo th&agrave;nh c&aacute;n bộ nguồn của c&ocirc;ng ty.</li>\r\n	<li>Sau khi được tuyển dụng, người lao động được k&yacute; hợp đồng lao động c&oacute; thời hạn, hết hạn hợp đồng c&ocirc;ng ty sẽ xem x&eacute;t k&yacute; tiếp hợp đồng lao động mới theo quy định hiện h&agrave;nh.</li>\r\n	<li>Được hưởng c&aacute;c chế độ Bảo hiểm x&atilde; hội, Bảo hiểm y tế, Bảo hiểm thất nghiệp , Bảo hiểm con người v&agrave; c&aacute;c chế độ kh&aacute;c theo quy định nh&agrave; nước ban h&agrave;nh.</li>\r\n</ul>\r\n\r\n<ol start="6">\r\n	<li><strong>Hồ sơ tuyển dụng bao gồm:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Đơn xin việc;</li>\r\n	<li>CV m&ocirc; tả kinh nghiệm v&agrave; qu&aacute; tr&igrave;nh c&ocirc;ng t&aacute;c, c&aacute;c văn bản giấy tờ x&aacute;c minh qu&aacute; tr&igrave;nh c&ocirc;ng t&aacute;c trước đ&oacute;.</li>\r\n	<li>02 ảnh 3x4;</li>\r\n	<li>C&aacute;c bằng cấp, bảng điểm, chứng chỉ, chứng nhận bản sao c&ocirc;ng chứng.</li>\r\n	<li>Sơ yếu l&yacute; lịch theo mẫu 04 trang, c&oacute; d&aacute;n ảnh, ghi đầy đủ c&aacute;c th&ocirc;ng tin, c&oacute; x&aacute;c nhận của ch&iacute;nh quyền địa phương, thời gian x&aacute;c nhận dưới 06 th&aacute;ng (t&iacute;nh đến ng&agrave;y nộp hồ sơ);</li>\r\n	<li>Bản sao c&ocirc;ng chứng giấy khai sinh;</li>\r\n	<li>Giấy kh&aacute;m sức khỏe do trung t&acirc;m y tế, bệnh viện đa khoa từ cấp huyện (thị x&atilde;) trở l&ecirc;n cấp thời gian kh&ocirc;ng qu&aacute; 06 th&aacute;ng t&iacute;nh đến ng&agrave;y nộp hồ sơ;</li>\r\n	<li>Bản photo chứng minh thư nh&acirc;n d&acirc;n.</li>\r\n	<li>Bản photo sổ Bảo hiểm x&atilde; hội (nếu c&oacute;). &nbsp;</li>\r\n</ul>\r\n\r\n<ol start="7">\r\n	<li><strong>Thời gian nhận hồ sơ v&agrave; địa chỉ nộp hồ sơ:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Nhận hồ sơ trực tiếp tại Ph&ograve;ng Tổ chức &ndash; Nh&acirc;n sự</li>\r\n	<li>Địa chỉ: C&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6, T&ograve;a nh&agrave; TM, Khu Đ&ocirc; thị Văn Kh&ecirc;, Phường La Kh&ecirc;, Quận H&agrave; Đ&ocirc;ng, Th&agrave;nh phố H&agrave; Nội.</li>\r\n	<li>Nhận hồ sơ trong giờ h&agrave;nh ch&iacute;nh h&agrave;ng ng&agrave;y từ thứ 2 đến thứ 6 h&agrave;ng tuần. C&ocirc;ng ty kh&ocirc;ng ho&agrave;n trả hồ sơ đối với c&aacute;c trường hợp kh&ocirc;ng tr&uacute;ng tuyển.</li>\r\n	<li>Thời gian nhận hồ sơ từ ng&agrave;y 18/3/2016 đến hết ng&agrave;y 30/4/2016.</li>\r\n	<li>Mọi chi tiết xin li&ecirc;n hệ với b&agrave; Cao Thị An - ĐT: 0905 247 258 hoặc ph&ograve;ng Tổ chức Nh&acirc;n sự 04 221 69772 trong giờ h&agrave;nh ch&iacute;nh.</li>\r\n</ul>\r\n', '50s26m23h-03062017-td21491979927.jpg', '2017-06-03', 0, 0, 1, 'tuyen-dung-nhan-vien-ky-thuat-01-nguoi'),
(36, 'Tuyển dụng kỹ sư bảo hộ - an toàn lao động', '<p>Tuyển dụng kỹ sư bảo hộ - an to&agrave;n lao động</p>\r\n', '<h2>Tuyển dụng kỹ sư bảo hộ - an to&agrave;n lao động</h2>\r\n\r\n<table style="width:705px">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt="" src="http://songda6.com.vn/editor/elfinder/files/en/Hinhcongty/Logo.JPG" style="height:96px; width:109px" />&nbsp;</td>\r\n			<td>\r\n			<p><strong>C&Ocirc;NG TY CỔ PHẦN S&Ocirc;NG Đ&Agrave; 6</strong></p>\r\n\r\n			<p>Nh&agrave; TM - Khu đ&ocirc; thị Văn Kh&ecirc; - Phường La Kh&ecirc; - Quận H&agrave; Đ&ocirc;ng - TP H&agrave; Nội</p>\r\n\r\n			<p><strong>Điện thoại:&nbsp;</strong>(+84-4) 22169622 - Fax (+84-4) 22253366</p>\r\n\r\n			<p><strong>Email:&nbsp;</strong>congtycophansongda6@songda6.com.vn</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>&nbsp;</strong></p>\r\n\r\n<p><strong>TH&Ocirc;NG B&Aacute;O TUYỂN DỤNG</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp; &nbsp; Hiện nay c&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6 c&oacute; nhu cầu tuyển dụng như sau:</p>\r\n\r\n<ol>\r\n	<li><strong>Vị tr&iacute; c&ocirc;ng việc</strong></li>\r\n</ol>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Kỹ sư bảo hộ - an to&agrave;n lao động</p>\r\n\r\n<ol start="2">\r\n	<li><strong>Ti&ecirc;u chuẩn:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Chỉ tuyển ứng vi&ecirc;n nam.</li>\r\n	<li>Tốt nghiệp đại học ch&iacute;nh quy đ&uacute;ng chuy&ecirc;n ng&agrave;nh cần tuyển.</li>\r\n	<li>Ưu ti&ecirc;n c&aacute;c ứng vi&ecirc;n đ&atilde; c&oacute; kinh nghiệm l&agrave;m việc trong lĩnh vực chuy&ecirc;n m&ocirc;n.</li>\r\n	<li>Y&ecirc;u cầu ngoại h&igrave;nh trung b&igrave;nh kh&aacute; trở l&ecirc;n, c&oacute; đủ sức khỏe để l&agrave;m việc theo quy định hiện h&agrave;nh.</li>\r\n	<li>C&oacute; &yacute; thức kỷ luật v&agrave; tr&aacute;ch nhiệm cao với c&ocirc;ng việc.</li>\r\n	<li>Ưu ti&ecirc;n ứng vi&ecirc;n nhanh nhẹn, khả năng giao tiếp tốt, kỹ năng đ&agrave;m ph&aacute;n, thuyết tr&igrave;nh, phối hợp v&agrave; l&agrave;m việc theo nh&oacute;m tốt, kỹ năng quản l&yacute; thời gian, sắp xếp giải quyết c&ocirc;ng việc hiệu quả, chịu được cường độ l&agrave;m việc cao.</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol start="3">\r\n	<li><strong>Nơi l&agrave;m việc:</strong></li>\r\n</ol>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp; C&ocirc;ng trường x&acirc;y dựng dự &aacute;n Thủy điện Xekaman 1 v&agrave; San Xay thuộc địa b&agrave;n huyện San Xay, tỉnh A Ta Pư v&agrave; dự &aacute;n Thủy điện Nậm Lik thuộc địa b&agrave;n huyện Phon Hong, tỉnh Vi&ecirc;ng Chăn, Nước cộng h&ograve;a d&acirc;n chủ nh&acirc;n d&acirc;n L&agrave;o</p>\r\n\r\n<ol start="4">\r\n	<li><strong>Tiền lương v&agrave; c&aacute;c chế độ kh&aacute;c:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Tiền lương được trả căn cứ v&agrave;o vị tr&iacute; c&ocirc;ng t&aacute;c, năng suất lao động, theo định mức kho&aacute;n của c&ocirc;ng ty. Mức lương khởi điểm sau thử việc từ 8.000.000 đến 10.000.000 trở l&ecirc;n t&ugrave;y theo hiệu quả v&agrave; năng suất l&agrave;m việc.</li>\r\n	<li>C&oacute; chế độ đ&atilde;i ngộ, ph&uacute;c lợi tốt với c&aacute;c ng&agrave;y nghỉ, Lễ, Tết, mức thưởng theo năng suất l&agrave;m việc v&agrave; kết quả sản xuất kinh doanh.</li>\r\n	<li>Được đ&agrave;o tạo n&acirc;ng cao về chuy&ecirc;n m&ocirc;n v&agrave; kỹ năng quản l&yacute; trong nước v&agrave; nước ngo&agrave;i.</li>\r\n	<li>Khả năng thăng tiến cao, c&oacute; cơ hội được lựa chọn v&agrave; đ&agrave;o tạo th&agrave;nh c&aacute;n bộ nguồn của c&ocirc;ng ty.</li>\r\n	<li>Sau khi được tuyển dụng, người lao động được k&yacute; hợp đồng lao động c&oacute; thời hạn, hết hạn hợp đồng c&ocirc;ng ty sẽ xem x&eacute;t k&yacute; tiếp hợp đồng lao động mới theo quy định hiện h&agrave;nh.</li>\r\n	<li>Được hưởng c&aacute;c chế độ Bảo hiểm x&atilde; hội, Bảo hiểm y tế, Bảo hiểm thất nghiệp v&agrave; c&aacute;c chế độ kh&aacute;c theo quy định nh&agrave; nước ban h&agrave;nh.</li>\r\n	<li>C&ocirc;ng ty bố tr&iacute; nơi ở miễn ph&iacute; cho người lao động.</li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<ol start="5">\r\n	<li><strong>Hồ sơ tuyển dụng bao gồm:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Đơn xin việc;</li>\r\n	<li>02 ảnh 3x4;</li>\r\n	<li>C&aacute;c bằng cấp, bảng điểm, chứng chỉ, chứng nhận bản sao c&ocirc;ng chứng.</li>\r\n	<li>Sơ yếu l&yacute; lịch mẫu 04 trang, c&oacute; d&aacute;n ảnh, ghi đầy đủ c&aacute;c th&ocirc;ng tin, c&oacute; x&aacute;c nhận của ch&iacute;nh quyền địa phương, thời gian x&aacute;c nhận dưới 06 th&aacute;ng (t&iacute;nh đến ng&agrave;y nộp hồ sơ);</li>\r\n	<li>Bản sao c&ocirc;ng chứng giấy khai sinh;</li>\r\n	<li>Giấy kh&aacute;m sức khỏe do trung t&acirc;m y tế, bệnh viện đa khoa từ cấp huyện (thị x&atilde;) trở l&ecirc;n cấp thời gian kh&ocirc;ng qu&aacute; 06 th&aacute;ng t&iacute;nh đến ng&agrave;y nộp hồ sơ;</li>\r\n	<li>Bản photo chứng minh thư nh&acirc;n d&acirc;n. &nbsp;</li>\r\n</ul>\r\n\r\n<ol start="6">\r\n	<li><strong>Địa chỉ nộp hồ sơ:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Hồ sơ nộp tại Ph&ograve;ng Tổ chức &ndash; Nh&acirc;n sự, C&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6;</li>\r\n	<li>Địa chỉ: T&ograve;a nh&agrave; TM, Khu Đ&ocirc; thị Văn Kh&ecirc;, Phường La Kh&ecirc;, Quận H&agrave; Đ&ocirc;ng, Th&agrave;nh phố H&agrave; Nội.</li>\r\n	<li>Nhận hồ sơ li&ecirc;n tục kh&ocirc;ng hạn chế thời gian trong giờ h&agrave;nh ch&iacute;nh h&agrave;ng ng&agrave;y từ thứ 2 đến s&aacute;ng thứ 7 h&agrave;ng tuần.</li>\r\n	<li>Mọi chi tiết xin li&ecirc;n hệ với b&agrave; Cao Thị An - ĐT: 0905 247 258 hoặc hoặc Ph&ograve;ng Tổ chức Nh&acirc;n sự - ĐT: 04 221 69772 trong giờ h&agrave;nh ch&iacute;nh.</li>\r\n	<li>C&aacute;c ứng vi&ecirc;n kh&ocirc;ng c&oacute; điều kiện nộp hồ sơ trực tiếp c&oacute; thể gửi hồ sơ qua đường bưu điện theo địa chỉ tr&ecirc;n.&nbsp;</li>\r\n</ul>\r\n', '59s27m23h-03062017-tuyen_dung1463459336.jpg', '2017-06-03', 0, 0, 1, 'tuyen-dung-ky-su-bao-ho-an-toan-lao-dong'),
(37, 'Tuyển dụng lái xe ô tô hạng C và nhân viên máy ủi', '<p>Tuyển dụng l&aacute;i xe &ocirc; t&ocirc; hạng C v&agrave; nh&acirc;n vi&ecirc;n m&aacute;y ủi</p>\r\n', '<h2>Vị tr&iacute; c&ocirc;ng việc v&agrave; số lượng tuyển dụng L&aacute;i xe &ocirc; t&ocirc; hạng C : 10 người Vận h&agrave;nh m&aacute;y ủi: 02 người</h2>\r\n\r\n<table style="width:705px">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt="" src="http://songda6.com.vn/editor/elfinder/files/en/Hinhcongty/Logo.JPG" style="height:96px; width:109px" />&nbsp;</td>\r\n			<td>\r\n			<p><strong>C&Ocirc;NG TY CỔ PHẦN S&Ocirc;NG Đ&Agrave; 6</strong></p>\r\n\r\n			<p>Nh&agrave; TM - Khu đ&ocirc; thị Văn Kh&ecirc; - Phường La Kh&ecirc; - Quận H&agrave; Đ&ocirc;ng - TP H&agrave; Nội</p>\r\n\r\n			<p><strong>Điện thoại:&nbsp;</strong>(+84-4) 22169622 - Fax (+84-4) 22253366</p>\r\n\r\n			<p><strong>Email:&nbsp;</strong>congtycophansongda6@songda6.com.vn</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>&nbsp;</strong></p>\r\n\r\n<p><strong>TH&Ocirc;NG B&Aacute;O TUYỂN DỤNG</strong></p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp;Hiện nay c&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6 c&oacute; nhu cầu tuyển dụng như sau:</p>\r\n\r\n<ol>\r\n	<li><strong>Vị tr&iacute; c&ocirc;ng việc v&agrave; số lượng tuyển dụng</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>L&aacute;i xe &ocirc; t&ocirc; hạng C : 10 người</li>\r\n	<li>Vận h&agrave;nh m&aacute;y ủi: 02 người</li>\r\n</ul>\r\n\r\n<ol start="2">\r\n	<li><strong>Ti&ecirc;u chuẩn:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>L&agrave; nam giới, tuổi đời kh&ocirc;ng qu&aacute; 35 tuổi;</li>\r\n	<li>C&oacute; đủ sức khỏe để l&agrave;m việc tại c&ocirc;ng ty.</li>\r\n</ul>\r\n\r\n<ol start="3">\r\n	<li><strong>Nơi l&agrave;m việc:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>C&ocirc;ng tr&igrave;nh Thủy điện Đồng Văn, x&atilde; Đồng Văn, huyện Quế Phong, tỉnh Nghệ An</li>\r\n	<li>C&ocirc;ng trường x&acirc;y dựng dự &aacute;n Thủy điện Xekaman 1 v&agrave; San Xay thuộc địa b&agrave;n huyện San Xay, tỉnh A Ta Pư v&agrave; dự &aacute;n Thủy điện Nậm Lik thuộc địa b&agrave;n huyện Phon Hong, tỉnh Vi&ecirc;ng Chăn, Nước cộng h&ograve;a d&acirc;n chủ nh&acirc;n d&acirc;n L&agrave;o</li>\r\n</ul>\r\n\r\n<ol start="4">\r\n	<li><strong>Tiền lương v&agrave; c&aacute;c chế độ kh&aacute;c:</strong></li>\r\n</ol>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp;Tiền lương được trả căn cứ v&agrave;o vị tr&iacute; c&ocirc;ng t&aacute;c, năng suất lao động, theo định mức kho&aacute;n của c&ocirc;ng ty.</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; Mức lương từ&nbsp;<strong>7.000.000đ đến 12.000.000 đồng</strong>&nbsp;t&ugrave;y theo hiệu quả v&agrave; năng suất l&agrave;m việc đối với từng vị tr&iacute;. Mức lương b&igrave;nh qu&acirc;n năm 2014 của c&aacute;n bộ c&ocirc;ng nh&acirc;n vi&ecirc;n C&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6 l&agrave;&nbsp;<strong>8.534.000 đồng</strong>.</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp;C&ocirc;ng ty c&oacute; chế độ&nbsp;<strong>đ&atilde;i ngộ, ph&uacute;c lợi tốt bằng vật chất v&agrave; tinh thần&nbsp;</strong>với c&aacute;c ng&agrave;y nghỉ lễ:&nbsp;<em>Tết Dương lịch, Tết &Acirc;m lịch, Giỗ Tổ H&ugrave;ng Vương, Tết Chiến Thắng 30/4, Quốc tế lao động 1/5 v&agrave; Quốc kh&aacute;nh 2/9.</em>&nbsp; Chế độ nghỉ ph&eacute;p năm theo quy định hiện h&agrave;nh của Nh&agrave; nước v&agrave; theo Thoả ước lao động tập thể của C&ocirc;ng ty. H&agrave;ng năm được&nbsp;<strong>hưởng mức thưởng</strong>&nbsp;theo năng suất l&agrave;m việc v&agrave; kết quả sản xuất kinh doanh.</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp; Sau khi được tuyển dụng, người lao động kh&ocirc;ng phải tham gia thử việc m&agrave; được&nbsp;<strong>k&yacute; hợp đồng lao động c&oacute; thời hạn 3 năm (36 th&aacute;ng),</strong>&nbsp;hết hạn hợp đồng c&ocirc;ng ty sẽ xem x&eacute;t k&yacute; tiếp hợp đồng lao động mới theo quy định hiện h&agrave;nh. Được trang bị bảo hộ lao động theo c&ocirc;ng việc được giao, đảm bảo an to&agrave;n lao động.</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp;Người lao động được&nbsp;<strong>hưởng c&aacute;c chế độ Bảo hiểm x&atilde; hội, Bảo hiểm y tế, Bảo hiểm thất nghiệp, Bảo hiểm con người</strong>&nbsp;v&agrave; c&aacute;c chế độ kh&aacute;c theo quy định nh&agrave; nước ban h&agrave;nh.</p>\r\n\r\n<p>&nbsp; &nbsp; &nbsp; &nbsp;C&ocirc;ng ty bố tr&iacute;&nbsp;<strong>nơi ở miễn ph&iacute;</strong>&nbsp;cho người lao động tại đơn vị.</p>\r\n\r\n<ol start="5">\r\n	<li><strong>Hồ sơ tuyển dụng bao gồm:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Đơn xin việc v&agrave; 02 ảnh 3x4;</li>\r\n	<li>C&aacute;c bằng cấp, chứng chỉ đ&agrave;o tạo c&ocirc;ng chứng;</li>\r\n	<li>Hồ sơ gốc, bằng gốc nếu l&agrave; c&ocirc;ng nh&acirc;n vận h&agrave;nh m&aacute;y x&acirc;y dựng hoặc l&aacute;i xe</li>\r\n	<li>Sơ yếu l&yacute; lịch mẫu 04 trang, c&oacute; d&aacute;n ảnh, ghi đầy đủ c&aacute;c th&ocirc;ng tin, c&oacute; x&aacute;c nhận của ch&iacute;nh quyền địa phương, thời gian x&aacute;c nhận dưới 06 th&aacute;ng (t&iacute;nh đến ng&agrave;y nộp hồ sơ);</li>\r\n	<li>Bản sao c&ocirc;ng chứng giấy khai sinh; chứng minh thư nh&acirc;n d&acirc;n; sổ hộ khẩu.</li>\r\n	<li>Giấy kh&aacute;m sức khỏe do trung t&acirc;m y tế, bệnh viện đa khoa từ cấp huyện (thị x&atilde;) trở l&ecirc;n cấp thời gian kh&ocirc;ng qu&aacute; 03 th&aacute;ng t&iacute;nh đến ng&agrave;y nộp hồ sơ (y&ecirc;u cầu theo mẫu 04 trang của Bộ Y tế ban h&agrave;nh)</li>\r\n</ul>\r\n\r\n<ol start="6">\r\n	<li><strong>Địa chỉ nộp hồ sơ:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Hồ sơ nộp tại Ph&ograve;ng Tổ chức &ndash; Nh&acirc;n sự, C&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6;</li>\r\n	<li>Địa chỉ: T&ograve;a nh&agrave; TM, Khu Đ&ocirc; thị Văn Kh&ecirc;, Phường La Kh&ecirc;, Quận H&agrave; Đ&ocirc;ng, Th&agrave;nh phố H&agrave; Nội. C&aacute;c ứng vi&ecirc;n kh&ocirc;ng c&oacute; điều kiện nộp hồ sơ trực tiếp c&oacute; thể gửi hồ sơ qua đường bưu điện theo địa chỉ tr&ecirc;n.</li>\r\n	<li>Nhận hồ sơ li&ecirc;n tục kh&ocirc;ng hạn chế thời gian trong giờ h&agrave;nh ch&iacute;nh h&agrave;ng ng&agrave;y từ thứ 2 đến thứ 6 h&agrave;ng tuần. Mọi chi tiết xin li&ecirc;n hệ với b&agrave; Cao Thị An - ĐT: 0905 247 258 hoặc Ph&ograve;ng Tổ chức Nh&acirc;n sự 04.221.69772 trong giờ h&agrave;nh ch&iacute;nh.</li>\r\n</ul>\r\n', '', '2017-06-01', 0, 0, 1, 'tuyen-dung-lai-xe-o-to-hang-c-va-nhan-vien-may-ui'),
(38, 'Tuyển dụng kỹ sư phòng Dự án - Đấu thầu', '<p>Tuyển dụng kỹ sư ph&ograve;ng Dự &aacute;n - Đấu thầu</p>\r\n', '<h2>Tuyển dụng kỹ sư ph&ograve;ng Dự &aacute;n - Đấu thầu: - 01 kỹ sư ch&iacute;nh dự &aacute;n. - 03 kỹ sư dự &aacute;n.</h2>\r\n\r\n<table style="width:705px">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt="" src="http://songda6.com.vn/editor/elfinder/files/en/Hinhcongty/Logo.JPG" style="height:96px; width:109px" />&nbsp;</td>\r\n			<td>\r\n			<p><strong>C&Ocirc;NG TY CỔ PHẦN S&Ocirc;NG Đ&Agrave; 6</strong></p>\r\n\r\n			<p>Nh&agrave; TM - Khu đ&ocirc; thị Văn Kh&ecirc; - Phường La Kh&ecirc; - Quận H&agrave; Đ&ocirc;ng - TP H&agrave; Nội</p>\r\n\r\n			<p><strong>Điện thoại:&nbsp;</strong>(+84-4) 22169622 - Fax (+84-4) 22253366</p>\r\n\r\n			<p><strong>Email:&nbsp;</strong>congtycophansongda6@songda6.com.vn</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p><strong>&nbsp;</strong></p>\r\n\r\n<p><strong>TH&Ocirc;NG B&Aacute;O TUYỂN DỤNG</strong></p>\r\n\r\n<p><strong>&nbsp;</strong></p>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Hiện nay c&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6 c&oacute; nhu cầu tuyển dụng như sau:</p>\r\n\r\n<ol>\r\n	<li><strong>Vị tr&iacute; tuyển dụng:&nbsp;</strong><br />\r\n	<strong>Kỹ sư ch&iacute;nh dự &aacute;n (Số lượng: 01)</strong><br />\r\n	- Mức lương tuyển dụng:&nbsp;<strong>10</strong>.<strong>000.000 đồng &ndash; 15.000.000 đồng</strong>&nbsp;(chưa bao gồm tiền lương tăng ca, tiền thưởng th&aacute;ng lương thứ 13, tiền thưởng theo dự &aacute;n, bồi dưỡng c&aacute;c dịp Lễ, Tết&hellip;). Ứng vi&ecirc;n xuất sắc c&oacute; thể đề xuất v&agrave; thỏa thuận mức lương 20.000.000 đồng.<br />\r\n	- M&ocirc; tả c&ocirc;ng việc: Phụ tr&aacute;ch nh&oacute;m kỹ sư lập hồ sơ đề xuất kỹ thuật phục vụ đấu thầu, cụ thể:<br />\r\n	- Lập kế hoạch thực hiện v&agrave; ph&acirc;n c&ocirc;ng nh&acirc;n sự thực hiện c&aacute;c phần việc theo hồ sơ đề suất.<br />\r\n	- Lập kế hoạch v&agrave; trực tiếp khảo s&aacute;t hiện trường phục vụ lập hồ sơ thầu.<br />\r\n	- Thực hiện c&aacute;c c&ocirc;ng việc ch&iacute;nh theo y&ecirc;u cầu hồ sơ mời thầu: tổng tiến độ; biện ph&aacute;p thi c&ocirc;ng chủ đạo; sơ đồ tổ chức c&ocirc;ng trường; tr&igrave;nh tự lu&acirc;n chuyển c&ocirc;ng việc&hellip;<br />\r\n	- Tham gia đ&agrave;m ph&aacute;n hợp đồng<br />\r\n	- Hỗ trợ kỹ thuật bộ phận x&acirc;y dựng khi dự &aacute;n thi c&ocirc;ng.<br />\r\n	<br />\r\n	<strong>Kỹ sư dự &aacute;n (Số lượng: 03)</strong><br />\r\n	- Mức lương tuyển dụng:&nbsp;<strong>10</strong>.<strong>000.000 đồng &ndash; 12.000.000 đồng</strong>&nbsp;(chưa bao gồm tiền lương tăng ca, tiền thưởng th&aacute;ng lương thứ 13, tiền thưởng theo dự &aacute;n, bồi dưỡng c&aacute;c dịp Lễ, Tết&hellip;)<br />\r\n	- M&ocirc; tả c&ocirc;ng việc: Nh&acirc;n vi&ecirc;n lập hồ sơ đề xuất kỹ thuật phục vụ đấu thầu, c&ocirc;ng việc cụ thể:<br />\r\n	- Thiết kế bản vẽ biện ph&aacute;p thi c&ocirc;ng chi tiết<br />\r\n	- B&oacute;c t&aacute;ch khối lượng thiết kế, kiểm tra khối lượng Bill thầu.<br />\r\n	- Lập biện ph&aacute;p thi c&ocirc;ng chi tiết c&aacute;c phần việc: Đ&agrave;o đắp, b&ecirc; t&ocirc;ng, HSE,&hellip;<br />\r\n	- Tham gia triển khai dự &aacute;n nếu được y&ecirc;u cầ</li>\r\n</ol>\r\n\r\n<ol start="2">\r\n	<li><strong>Địa điểm l&agrave;m việc:&nbsp;</strong>Ph&ograve;ng Dự &aacute;n Đấu thầu, C&ocirc;ng ty CP S&ocirc;ng Đ&agrave; 6 (H&agrave; Nội)<br />\r\n	&nbsp;</li>\r\n	<li><strong>Ti&ecirc;u chuẩn tuyển dụng</strong><br />\r\n	- Chỉ tuyển ứng vi&ecirc;n nam.<br />\r\n	- Tốt nghiệp từ đại học trở l&ecirc;n c&aacute;c chuy&ecirc;n ng&agrave;nh về kỹ thuật x&acirc;y dựng d&acirc;n dụng v&agrave; c&ocirc;ng nghiệp; thủy lợi - thủy điện; kiến tr&uacute;c; c&ocirc;ng tr&igrave;nh giao th&ocirc;ng.<br />\r\n	- C&oacute; tối thiểu 3 năm kinh nghiệm c&ocirc;ng t&aacute;c thực tế tại c&aacute;c dự &aacute;n x&acirc;y dựng (đối với vị tr&iacute; kỹ sư dự &aacute;n) v&agrave; 5 năm kinh nghiệm (đối với vị tr&iacute; kỹ sư ch&iacute;nh); ưu ti&ecirc;n những ứng vi&ecirc;n đ&atilde; c&oacute; kinh nghiệm l&agrave;m trưởng nh&oacute;m kỹ thuật dự &aacute;n hoặc c&aacute;c ứng vi&ecirc;n c&oacute; kinh nghiệm l&agrave;m tư vấn thiết kế.<br />\r\n	- Sử dụng th&agrave;nh thạo CAD, Office v&agrave; tối thiểu một phần mềm quản l&yacute; dự &aacute;n như Project, Primavela - P6,&hellip;ưu ti&ecirc;n c&aacute;c ứng vi&ecirc;n sử dụng được c&aacute;c phần mềm t&iacute;nh kết cấu như SAP.<br />\r\n	- Ứng vi&ecirc;n phải chủ động đọc được t&agrave;i liệu kỹ thuật dự &aacute;n v&agrave; lập được bản vẽ, tiến độ bằng tiếng Anh. Ưu ti&ecirc;n c&aacute;c ứng vi&ecirc;n th&agrave;nh thạo nghe, n&oacute;i, đọc, viết Tiếng Anh v&agrave; c&aacute;c ngoại ngữ kh&aacute;c.<br />\r\n	- Y&ecirc;u cầu c&oacute; khả năng giao tiếp tốt, kỹ năng đ&agrave;m ph&aacute;n, thuyết tr&igrave;nh, phối hợp v&agrave; l&agrave;m việc theo nh&oacute;m tốt, kỹ năng quản l&yacute; thời gian, sắp xếp giải quyết c&ocirc;ng việc hiệu quả, c&oacute; sức khỏe tốt, chịu được cường độ l&agrave;m việc cao, c&oacute; &yacute; thức kỷ luật v&agrave; tr&aacute;ch nhiệm cao với c&ocirc;ng việc.<br />\r\n	- Y&ecirc;u cầu ứng vi&ecirc;n c&oacute; khả năng đi c&ocirc;ng t&aacute;c ngắn ng&agrave;y hoặc d&agrave;i ng&agrave;y theo y&ecirc;u cầu của c&ocirc;ng việc.</li>\r\n</ol>\r\n\r\n<ol start="4">\r\n	<li><strong>C&aacute;c chế độ đ&atilde;i ngộ v&agrave; ph&uacute;c lợi</strong><br />\r\n	- C&oacute; chế độ đ&atilde;i ngộ, ph&uacute;c lợi tốt với c&aacute;c ng&agrave;y nghỉ, Lễ, Tết<br />\r\n	- Được hưởng mức thưởng theo th&agrave;nh t&iacute;ch thực hiện dự &aacute;n v&agrave; chế độ lương th&aacute;ng 13 theo quy định của C&ocirc;ng ty.<br />\r\n	- Được đ&agrave;o tạo n&acirc;ng cao về chuy&ecirc;n m&ocirc;n v&agrave; kỹ năng quản l&yacute; trong nước v&agrave; nước ngo&agrave;i.<br />\r\n	- Được trang bị đầy đủ trang thiết bị phục vụ c&ocirc;ng việc: B&agrave;n l&agrave;m việc, m&aacute;y t&iacute;nh x&aacute;ch tay hoặc m&aacute;y t&iacute;nh b&agrave;n theo nhu cầu, c&aacute;c phần mềm c&ocirc;ng cụ cần thiết.<br />\r\n	- Được đ&agrave;i thọ to&agrave;n bộ chi ph&iacute; vật chất trong qu&aacute; tr&igrave;nh đi c&ocirc;ng t&aacute;c theo y&ecirc;u cầu của c&ocirc;ng ty<br />\r\n	- Khả năng thăng tiến cao, c&oacute; cơ hội được lựa chọn v&agrave; đ&agrave;o tạo th&agrave;nh c&aacute;n bộ nguồn của c&ocirc;ng ty.<br />\r\n	- Được tạo điều kiện về t&agrave;i ch&iacute;nh v&agrave; thời gian đ&aacute;p ứng c&aacute;c nhu cầu học tập của c&aacute; nh&acirc;n ph&ugrave; hợp với nhu cầu của c&ocirc;ng ty (MBA, Thạc sỹ, c&aacute;c lớp n&acirc;ng cao nghiệp vụ, kỹ năng)<br />\r\n	- Sau khi được tuyển dụng, người lao động được k&yacute; hợp đồng lao động c&oacute; thời hạn 36 th&aacute;ng, hết hạn hợp đồng c&ocirc;ng ty sẽ xem x&eacute;t k&yacute; tiếp hợp đồng lao động mới theo quy định hiện h&agrave;nh.<br />\r\n	- Được hưởng c&aacute;c chế độ Bảo hiểm x&atilde; hội, Bảo hiểm y tế, Bảo hiểm thất nghiệp , Bảo hiểm con người v&agrave; c&aacute;c chế độ kh&aacute;c theo quy định nh&agrave; nước ban h&agrave;nh.</li>\r\n</ol>\r\n\r\n<ol start="5">\r\n	<li><strong>Hồ sơ tuyển dụng bao gồm:</strong><br />\r\n	- Đơn xin việc;<br />\r\n	- CV m&ocirc; tả kinh nghiệm v&agrave; qu&aacute; tr&igrave;nh c&ocirc;ng t&aacute;c, c&aacute;c văn bản giấy tờ x&aacute;c minh qu&aacute; tr&igrave;nh c&ocirc;ng t&aacute;c trước đ&oacute;.<br />\r\n	- 02 ảnh 3x4;<br />\r\n	- C&aacute;c bằng cấp, bảng điểm, chứng chỉ, chứng nhận bản sao c&ocirc;ng chứng.<br />\r\n	- Sơ yếu l&yacute; lịch theo mẫu 04 trang, c&oacute; d&aacute;n ảnh, ghi đầy đủ c&aacute;c th&ocirc;ng tin, c&oacute; x&aacute;c nhận của ch&iacute;nh quyền địa phương, thời gian x&aacute;c nhận dưới 06 th&aacute;ng (t&iacute;nh đến ng&agrave;y nộp hồ sơ);<br />\r\n	- Bản sao c&ocirc;ng chứng giấy khai sinh;<br />\r\n	- Giấy kh&aacute;m sức khỏe do trung t&acirc;m y tế, bệnh viện đa khoa từ cấp huyện (thị x&atilde;) trở l&ecirc;n cấp thời gian kh&ocirc;ng qu&aacute; 06 th&aacute;ng t&iacute;nh đến ng&agrave;y nộp hồ sơ;<br />\r\n	- Bản photo chứng minh thư nh&acirc;n d&acirc;n.<br />\r\n	- Bản photo sổ Bảo hiểm x&atilde; hội (nếu c&oacute;). &nbsp;</li>\r\n</ol>\r\n\r\n<ol start="6">\r\n	<li><strong>Thời gian nhận hồ sơ v&agrave; địa chỉ nộp hồ sơ:</strong><br />\r\n	- Nhận hồ sơ trực tiếp tại Ph&ograve;ng Tổ chức &ndash; Nh&acirc;n sự<br />\r\n	- Địa chỉ: C&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6, T&ograve;a nh&agrave; TM, Khu Đ&ocirc; thị Văn Kh&ecirc;, Phường La Kh&ecirc;, Quận H&agrave; Đ&ocirc;ng, Th&agrave;nh phố H&agrave; Nội.<br />\r\n	- Nhận hồ sơ trong giờ h&agrave;nh ch&iacute;nh h&agrave;ng ng&agrave;y từ thứ 2 đến thứ 6 h&agrave;ng tuần. C&ocirc;ng ty kh&ocirc;ng ho&agrave;n trả hồ sơ đối với c&aacute;c trường hợp kh&ocirc;ng tr&uacute;ng tuyển.<br />\r\n	- Thời gian nhận hồ sơ từ ng&agrave;y 01/8/2016 đến hết ng&agrave;y 31/8/2016.<br />\r\n	- Mọi chi tiết xin li&ecirc;n hệ với b&agrave; Cao Thị An - ĐT: 0905 247 258 hoặc ph&ograve;ng Tổ chức Nh&acirc;n sự 04 221 69772 trong giờ h&agrave;nh ch&iacute;nh.</li>\r\n</ol>\r\n', '09s29m23h-03062017-td21491979927.jpg', '2017-06-01', 0, 0, 1, 'tuyen-dung-ky-su-phong-du-an-dau-thau'),
(39, 'Tuyển dụng công nhân kỹ thuật', '<p>Tuyển dụng c&ocirc;ng nh&acirc;n kỹ thuật</p>\r\n', '<h2>Tuyển dụng c&ocirc;ng nh&acirc;n kỹ thuật</h2>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table style="width:705px">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt="" src="http://songda6.com.vn/editor/elfinder/files/en/Hinhcongty/Logo.JPG" style="height:96px; width:109px" />&nbsp;</td>\r\n			<td>\r\n			<p><strong>C&Ocirc;NG TY CỔ PHẦN S&Ocirc;NG Đ&Agrave; 6</strong></p>\r\n\r\n			<p>Nh&agrave; TM - Khu đ&ocirc; thị Văn Kh&ecirc; - Phường La Kh&ecirc; - Quận H&agrave; Đ&ocirc;ng - TP H&agrave; Nội</p>\r\n\r\n			<p><strong>Điện thoại:&nbsp;</strong>(+84-4) 22169622 - Fax (+84-4) 22253366</p>\r\n\r\n			<p><strong>Email:&nbsp;</strong>congtycophansongda6@songda6.com.vn</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<em>&nbsp;&nbsp;&nbsp;&nbsp;</em>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;</p>\r\n\r\n<p><strong>TH&Ocirc;NG B&Aacute;O TUYỂN DỤNG C&Ocirc;NG NH&Acirc;N KỸ THUẬT</strong></p>\r\n\r\n<p><strong>C&Ocirc;NG TY CỔ PHẦN S&Ocirc;NG Đ&Agrave; 6</strong></p>\r\n\r\n<p>Trụ sở ch&iacute;nh:&nbsp; T&ograve;a nh&agrave; TM, Khu Đ&ocirc; thị Văn Kh&ecirc;, Phường La Kh&ecirc;, Quận H&agrave; Đ&ocirc;ng, Th&agrave;nh phố H&agrave; Nội:</p>\r\n\r\n<p>Hiện nay c&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6 c&oacute; nhu cầu tuyển dụng như sau:</p>\r\n\r\n<ol>\r\n	<li><strong>Vị tr&iacute; c&ocirc;ng việc v&agrave; số lượng tuyển dụng</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Thợ h&agrave;n, g&ograve; h&agrave;n, sắt h&agrave;n, cơ kh&iacute; (kh&ocirc;ng hạn chế số lượng tuyển dụng)</li>\r\n	<li>C&ocirc;ng nh&acirc;n nề - b&ecirc; t&ocirc;ng, x&acirc;y lắp (kh&ocirc;ng hạn chế số lượng tuyển dụng)</li>\r\n	<li>C&ocirc;ng nh&acirc;n vận h&agrave;nh cần trục b&aacute;nh x&iacute;ch (01 người)</li>\r\n	<li>L&aacute;i xe &ocirc; t&ocirc; hạng C (10 người)</li>\r\n	<li>Lao động phổ th&ocirc;ng (kh&ocirc;ng hạn chế số lượng tuyển dụng)</li>\r\n</ul>\r\n\r\n<ol start="2">\r\n	<li><strong>Ti&ecirc;u chuẩn v&agrave; đối tượng tuyển dụng:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Tuổi đời kh&ocirc;ng qu&aacute; 40 tuổi;</li>\r\n	<li>C&oacute; đủ sức khỏe để l&agrave;m việc tại c&ocirc;ng ty.</li>\r\n</ul>\r\n\r\n<ol start="3">\r\n	<li><strong>Nơi l&agrave;m việc:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>L&agrave;m việc tại c&aacute;c c&ocirc;ng tr&igrave;nh c&ocirc;ng ty đang thi c&ocirc;ng như Thủy điện Đồng Văn (Nghệ An), Thủy điện S&ocirc;ng L&ocirc; 2 (H&agrave; Giang), Thủy điện Sử P&aacute;n (L&agrave;o Cai), Thủy điện S&ocirc;ng M&atilde; (Điện Bi&ecirc;n), Thủy điện Nậm Ban (Lai Ch&acirc;u), Thủy điện San Xay v&agrave; Xekaman 1 (Cộng h&ograve;a d&acirc;n chủ nh&acirc;n d&acirc;n L&agrave;o)</li>\r\n</ul>\r\n\r\n<ol start="4">\r\n	<li><strong>Tiền lương v&agrave; c&aacute;c chế độ kh&aacute;c:</strong></li>\r\n</ol>\r\n\r\n<p>Tiền lương được trả căn cứ v&agrave;o vị tr&iacute; c&ocirc;ng t&aacute;c, năng suất lao động, theo định mức kho&aacute;n của c&ocirc;ng ty.</p>\r\n\r\n<p>Mức lương từ&nbsp;<strong>6.000.000 đồng đến 10.000.000 đồng&nbsp;</strong>(đối với c&ocirc;ng nh&acirc;n c&oacute; nghề) v&agrave; từ&nbsp;<strong>8.000.000 đồng đến 12.000.000 đồng</strong>&nbsp;(đối với c&ocirc;ng nhận vận h&agrave;nh m&aacute;y v&agrave; l&aacute;i xe) t&ugrave;y theo hiệu quả v&agrave; năng suất l&agrave;m việc đối với từng vị tr&iacute;.</p>\r\n\r\n<p>C&ocirc;ng ty c&oacute; chế độ&nbsp;<strong>đ&atilde;i ngộ, ph&uacute;c lợi tốt bằng vật chất v&agrave; tinh thần</strong>&nbsp;với c&aacute;c ng&agrave;y nghỉ lễ:&nbsp;<em>Tết Dương lịch, Tết &Acirc;m lịch, Giỗ Tổ H&ugrave;ng Vương, Tết Chiến Thắng 30/4, Quốc tế lao động 1/5 v&agrave; Quốc Kh&aacute;nh 2/9.</em>&nbsp; Chế độ nghỉ ph&eacute;p năm theo quy định hiện h&agrave;nh của Nh&agrave; nước v&agrave; theo Thoả ước lao động tập thể của C&ocirc;ng ty. H&agrave;ng năm được&nbsp;<strong>hưởng mức thưởng</strong>&nbsp;theo năng suất l&agrave;m việc v&agrave; kết quả sản xuất kinh doanh.</p>\r\n\r\n<p>Sau khi được tuyển dụng, nếu đ&atilde; c&oacute; kinh nghiệm l&agrave;m việc, người lao động kh&ocirc;ng phải tham gia thử việc, tập nghề, được&nbsp;<strong>k&yacute; hợp đồng lao động c&oacute; thời hạn 3 năm (36 th&aacute;ng),</strong>&nbsp;hết hạn hợp đồng c&ocirc;ng ty sẽ xem x&eacute;t k&yacute; tiếp hợp đồng lao động mới theo quy định hiện h&agrave;nh. Được trang bị bảo hộ lao động theo c&ocirc;ng việc được giao, đảm bảo an to&agrave;n lao động.</p>\r\n\r\n<p>Người lao động chưa c&oacute; nghề được C&ocirc;ng ty hỗ trợ học nghề theo nhu cầu nh&acirc;n lực của C&ocirc;ng ty với&nbsp;<strong>mức t&agrave;i trợ học ph&iacute; từ 50% - 100%</strong>, tạo điều kiện cho người lao động vừa học vừa l&agrave;m, mở c&aacute;c lớp đ&agrave;o tạo nghề ngay tại C&ocirc;ng trường nơi người lao động l&agrave;m việc.</p>\r\n\r\n<p>Người lao động được&nbsp;<strong>hưởng c&aacute;c chế độ Bảo hiểm x&atilde; hội, Bảo hiểm y tế, Bảo hiểm thất nghiệp, Bảo hiểm con người</strong>&nbsp;v&agrave; c&aacute;c chế độ kh&aacute;c theo quy định nh&agrave; nước ban h&agrave;nh.</p>\r\n\r\n<p>C&ocirc;ng ty bố tr&iacute;&nbsp;<strong>nơi ở miễn ph&iacute;</strong>&nbsp;cho người lao động tại đơn vị.</p>\r\n\r\n<ol start="5">\r\n	<li><strong>Hồ sơ tuyển dụng bao gồm:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Đơn xin việc v&agrave; 02 ảnh 3x4;</li>\r\n	<li>C&aacute;c bằng cấp, chứng chỉ đ&agrave;o tạo c&ocirc;ng chứng;</li>\r\n	<li>Hồ sơ gốc, bằng gốc với nghề l&aacute;i xe v&agrave; vận h&agrave;nh</li>\r\n	<li>Sơ yếu l&yacute; lịch mẫu 04 trang, c&oacute; d&aacute;n ảnh, ghi đầy đủ c&aacute;c th&ocirc;ng tin, c&oacute; x&aacute;c nhận của ch&iacute;nh quyền địa phương, thời gian x&aacute;c nhận dưới 06 th&aacute;ng (t&iacute;nh đến ng&agrave;y nộp hồ sơ);</li>\r\n	<li>Bản sao c&ocirc;ng chứng giấy khai sinh; chứng minh thư nh&acirc;n d&acirc;n; sổ hộ khẩu.</li>\r\n	<li>Giấy kh&aacute;m sức khỏe do trung t&acirc;m y tế, bệnh viện đa khoa từ cấp huyện (thị x&atilde;) trở l&ecirc;n cấp thời gian kh&ocirc;ng qu&aacute; 03 th&aacute;ng t&iacute;nh đến ng&agrave;y nộp hồ sơ (y&ecirc;u cầu theo mẫu 04 trang của Bộ Y tế ban h&agrave;nh)</li>\r\n</ul>\r\n\r\n<ol start="6">\r\n	<li><strong>Địa chỉ nộp hồ sơ:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Hồ sơ nộp tại Ph&ograve;ng Tổ chức Nh&acirc;n sự, C&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6;</li>\r\n	<li>Địa chỉ: T&ograve;a nh&agrave; TM, Khu Đ&ocirc; thị Văn Kh&ecirc;, Phường La Kh&ecirc;, Quận H&agrave; Đ&ocirc;ng, Th&agrave;nh phố H&agrave; Nội. C&aacute;c ứng vi&ecirc;n kh&ocirc;ng c&oacute; điều kiện nộp hồ sơ trực tiếp c&oacute; thể gửi hồ sơ qua đường bưu điện theo địa chỉ tr&ecirc;n.</li>\r\n	<li>Nhận hồ sơ li&ecirc;n tục kh&ocirc;ng hạn chế thời gian trong giờ h&agrave;nh ch&iacute;nh h&agrave;ng ng&agrave;y từ thứ 2 đến thứ 6 h&agrave;ng tuần. Mọi chi tiết xin li&ecirc;n hệ với b&agrave; Cao Thị An (Trưởng ph&ograve;ng Tổ chức Nh&acirc;n sự) - ĐT: 0905 247 258 hoặc Ph&ograve;ng Tổ chức Nh&acirc;n sự - &nbsp;ĐT: 04.221.69772 trong giờ h&agrave;nh ch&iacute;nh.<br />\r\n	<br />\r\n	ĐƠN XIN VIỆC DOWNLOAD&nbsp;<a href="http://songda6.com.vn/editor/elfinder/files/MAU%20DON%20XIN%20VIEC/donxinviec.docx">TẠI Đ&Acirc;Y</a></li>\r\n</ul>\r\n', '52s29m23h-03062017-tuyen_dung1463459336.jpg', '2017-06-02', 0, 0, 1, 'tuyen-dung-cong-nhan-ky-thuat'),
(40, 'Thông báo tuyển dụng kỹ sư', '<p>Th&ocirc;ng b&aacute;o tuyển dụng kỹ sư</p>\r\n', '<h2>Vị tr&iacute; tuyển dụng: Nh&acirc;n vi&ecirc;n kỹ thuật (06 người)</h2>\r\n\r\n<table style="width:703px">\r\n	<tbody>\r\n		<tr>\r\n			<td><img alt="" src="http://songda6.com.vn/editor/elfinder/files/en/Hinhcongty/Logo.JPG" style="height:96px; width:109px" />&nbsp;</td>\r\n			<td>\r\n			<p><strong>C&Ocirc;NG TY CỔ PHẦN S&Ocirc;NG Đ&Agrave; 6</strong></p>\r\n\r\n			<p>Nh&agrave; TM - Khu đ&ocirc; thị Văn Kh&ecirc; - Phường La Kh&ecirc; - Quận H&agrave; Đ&ocirc;ng - TP H&agrave; Nội</p>\r\n\r\n			<p><strong>Điện thoại:&nbsp;</strong>(+84-4) 22169622 - Fax (+84-4) 22253366</p>\r\n\r\n			<p><strong>Email:&nbsp;</strong>congtycophansongda6@songda6.com.vn</p>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>TH&Ocirc;NG B&Aacute;O TUYỂN DỤNG</strong></p>\r\n\r\n<p><strong>C&Ocirc;NG TY CỔ PHẦN S&Ocirc;NG Đ&Agrave; 6</strong></p>\r\n\r\n<p>Hiện nay c&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6 c&oacute; nhu cầu tuyển dụng như sau:</p>\r\n\r\n<ol>\r\n	<li><strong>Vị tr&iacute; tuyển dụng: Nh&acirc;n vi&ecirc;n kỹ thuật (06 người)</strong></li>\r\n	<li><strong>Địa điểm l&agrave;m việc:&nbsp;</strong>Chi nh&aacute;nh S&ocirc;ng Đ&agrave; 6.03 (Nước CHDCND L&agrave;o), Chi nh&aacute;nh S&ocirc;ng Đ&agrave; 6.04 (H&agrave; Giang) v&agrave; Chi nh&aacute;nh S&ocirc;ng Đ&agrave; 6.05 (Nghệ An)</li>\r\n	<li><strong>Mức lương tuyển dụng:&nbsp;</strong>Theo năng lực v&agrave; kết quả sản xuất kinh doanh của C&ocirc;ng ty</li>\r\n	<li><strong>Ti&ecirc;u chuẩn tuyển dụng</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Tốt nghiệp đại học chuy&ecirc;n ng&agrave;nh: X&acirc;y dựng; Thủy lợi &ndash; Thủy điện; Thủy điện v&agrave; năng lượng t&aacute;i tạo; C&ocirc;ng tr&igrave;nh thủy&hellip;</li>\r\n	<li>C&oacute; kinh nghiệm tối thiểu 01 năm l&agrave;m việc trong lĩnh vực x&acirc;y dựng thủy lợi thủy điện.</li>\r\n	<li>Sử dụng được c&aacute;c phần mềm văn ph&ograve;ng cơ bản, c&aacute;c phần mềm chuy&ecirc;n ng&agrave;nh như AutoCad 3D, Revit, c&aacute;c phần mềm quản l&yacute; tiến độ&hellip;</li>\r\n	<li>Y&ecirc;u cầu c&oacute; khả năng giao tiếp tốt, kỹ năng đ&agrave;m ph&aacute;n, thuyết tr&igrave;nh, phối hợp v&agrave; l&agrave;m việc theo nh&oacute;m tốt, kỹ năng quản l&yacute; thời gian, sắp xếp giải quyết c&ocirc;ng việc hiệu quả, chịu được cường độ l&agrave;m việc cao, c&oacute; &yacute; thức kỷ luật v&agrave; tr&aacute;ch nhiệm cao với c&ocirc;ng việc.</li>\r\n</ul>\r\n\r\n<ol start="5">\r\n	<li><strong>C&aacute;c chế độ đ&atilde;i ngộ v&agrave; ph&uacute;c lợi</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>C&oacute; chế độ đ&atilde;i ngộ, ph&uacute;c lợi tốt với c&aacute;c ng&agrave;y nghỉ, Lễ, Tết, mức thưởng theo năng suất l&agrave;m việc v&agrave; kết quả sản xuất kinh doanh.</li>\r\n	<li>M&ocirc;i trường l&agrave;m việc chuy&ecirc;n nghiệp, năng động, c&oacute; nhiều cơ hội học hỏi v&agrave; ph&aacute;t triển bản th&acirc;n.</li>\r\n	<li>Được đ&agrave;o tạo n&acirc;ng cao về chuy&ecirc;n m&ocirc;n v&agrave; kỹ năng quản l&yacute; trong nước v&agrave; nước ngo&agrave;i.</li>\r\n	<li>Khả năng thăng tiến cao, c&oacute; cơ hội được lựa chọn v&agrave; đ&agrave;o tạo th&agrave;nh c&aacute;n bộ nguồn của c&ocirc;ng ty.</li>\r\n	<li>Sau khi được tuyển dụng, người lao động được k&yacute; hợp đồng lao động c&oacute; thời hạn, hết hạn hợp đồng c&ocirc;ng ty sẽ xem x&eacute;t k&yacute; tiếp hợp đồng lao động mới theo quy định hiện h&agrave;nh.</li>\r\n	<li>Được hưởng c&aacute;c chế độ Bảo hiểm x&atilde; hội, Bảo hiểm y tế, Bảo hiểm thất nghiệp , Bảo hiểm con người v&agrave; c&aacute;c chế độ kh&aacute;c theo quy định nh&agrave; nước ban h&agrave;nh.</li>\r\n</ul>\r\n\r\n<ol start="6">\r\n	<li><strong>Hồ sơ tuyển dụng bao gồm:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Đơn xin việc;</li>\r\n	<li>CV m&ocirc; tả kinh nghiệm v&agrave; qu&aacute; tr&igrave;nh c&ocirc;ng t&aacute;c, c&aacute;c văn bản giấy tờ x&aacute;c minh qu&aacute; tr&igrave;nh c&ocirc;ng t&aacute;c trước đ&oacute;.</li>\r\n	<li>02 ảnh 3x4;</li>\r\n	<li>C&aacute;c bằng cấp, bảng điểm, chứng chỉ, chứng nhận bản sao c&ocirc;ng chứng.</li>\r\n	<li>Sơ yếu l&yacute; lịch theo mẫu 04 trang, c&oacute; d&aacute;n ảnh, ghi đầy đủ c&aacute;c th&ocirc;ng tin, c&oacute; x&aacute;c nhận của ch&iacute;nh quyền địa phương, thời gian x&aacute;c nhận dưới 06 th&aacute;ng (t&iacute;nh đến ng&agrave;y nộp hồ sơ);</li>\r\n	<li>Bản sao c&ocirc;ng chứng giấy khai sinh;</li>\r\n	<li>Giấy kh&aacute;m sức khỏe do trung t&acirc;m y tế, bệnh viện đa khoa từ cấp huyện (thị x&atilde;) trở l&ecirc;n cấp thời gian kh&ocirc;ng qu&aacute; 06 th&aacute;ng t&iacute;nh đến ng&agrave;y nộp hồ sơ;</li>\r\n	<li>Bản photo chứng minh thư nh&acirc;n d&acirc;n.</li>\r\n	<li>Bản photo sổ Bảo hiểm x&atilde; hội (nếu c&oacute;). &nbsp;</li>\r\n</ul>\r\n\r\n<ol start="7">\r\n	<li><strong>Thời gian nhận hồ sơ v&agrave; địa chỉ nộp hồ sơ:</strong></li>\r\n</ol>\r\n\r\n<ul>\r\n	<li>Nhận hồ sơ trực tiếp tại Ph&ograve;ng Tổ chức &ndash; Nh&acirc;n sự</li>\r\n	<li>Địa chỉ: C&ocirc;ng ty Cổ phần S&ocirc;ng Đ&agrave; 6, T&ograve;a nh&agrave; TM, Khu Đ&ocirc; thị Văn Kh&ecirc;, Phường La Kh&ecirc;, Quận H&agrave; Đ&ocirc;ng, Th&agrave;nh phố H&agrave; Nội.</li>\r\n	<li>Nhận hồ sơ trong giờ h&agrave;nh ch&iacute;nh h&agrave;ng ng&agrave;y từ thứ 2 đến thứ 6 h&agrave;ng tuần. C&ocirc;ng ty kh&ocirc;ng ho&agrave;n trả hồ sơ đối với c&aacute;c trường hợp kh&ocirc;ng tr&uacute;ng tuyển.</li>\r\n	<li>Thời gian nhận hồ sơ từ ng&agrave;y 24/4/2017 đến hết ng&agrave;y 30/5/2017.</li>\r\n	<li>Mọi chi tiết xin li&ecirc;n hệ với b&agrave; Cao Thị An - ĐT: 0905 247 258 hoặc ph&ograve;ng Tổ chức Nh&acirc;n sự 04 221 69772 trong giờ h&agrave;nh ch&iacute;nh.</li>\r\n</ul>\r\n', '21s30m23h-03062017-td21491979927.jpg', '2017-06-03', 0, 0, 1, 'thong-bao-tuyen-dung-ky-su'),
(41, 'CÔNG TRÌNH CHUNG CƯ CT2 - VĂN KHÊ - HÀ ĐÔNG - HÀ NỘI', '<p>C&Ocirc;NG TR&Igrave;NH CHUNG CƯ CT2 - VĂN KH&Ecirc; - H&Agrave; Đ&Ocirc;NG - H&Agrave; NỘI</p>\r\n', '<h1>C&Ocirc;NG TR&Igrave;NH CHUNG CƯ CT2 - VĂN KH&Ecirc; - H&Agrave; Đ&Ocirc;NG - H&Agrave; NỘI</h1>\r\n\r\n<p>C&aacute;c th&ocirc;ng số kỹ thuật chủ yếu của c&ocirc;ng tr&igrave;nh:</p>\r\n\r\n<ul>\r\n	<li>Diện t&iacute;ch đất x&acirc;y dựng: 600 m<sup>2</sup></li>\r\n	<li>Mật độ x&acirc;y dựng: 56%</li>\r\n	<li>Số tầng: 25 tầng nổi v&agrave; 01 tầng hầm</li>\r\n	<li>Tổng diện t&iacute;ch s&agrave;n x&acirc;y dựng 750 m<sup>2</sup></li>\r\n	<li>Diện t&iacute;ch tầng hầm: 750 m<sup>2</sup></li>\r\n	<li>Diện t&iacute;ch s&agrave;n x&acirc;y dựng:40.000 m<sup>2</sup></li>\r\n	<li>Hệ thống giao th&ocirc;ng trục đứng: Cầu thang m&aacute;y v&agrave; thang bộ</li>\r\n	<li>Giải ph&aacute;p xử l&yacute; nền: Cọc khoan nhồi v&agrave; cọc&nbsp;&eacute;p</li>\r\n</ul>\r\n\r\n<p><img src="http://songda6.com.vn/uploads/project/CT2-2.jpg" /></p>\r\n', '25s31m23h-03062017-small_CT2-3.jpg', '2017-06-02', 0, 0, 1, 'cong-trinh-chung-cu-ct2-van-khe-ha-dong-ha-noi'),
(42, 'Công trình hỗn hợp thương mại kết hợp nhà ở TM', '<p>C&ocirc;ng tr&igrave;nh hỗn hợp thương mại kết hợp nh&agrave; ở TM</p>\r\n', '<h1>C&Ocirc;NG TR&Igrave;NH HỖN HỢP THƯƠNG MẠI KẾT HỢP NH&Agrave; Ở TM</h1>\r\n\r\n<p><strong>- C&ocirc;ng tr&igrave;nh</strong>: Hỗn hợp thương mại kết hợp nh&agrave; ở TM</p>\r\n\r\n<p><strong>- Thuộc dự &aacute;n:&nbsp;</strong>Khu đ&ocirc; thị mới Văn Kh&ecirc; - quận H&agrave; Đ&ocirc;ng - th&agrave;nh phố H&agrave; Nội.</p>\r\n\r\n<p><strong>- Tổng mức đầu tư</strong>: 70.144.000.000 đồng.( Theo TK Cơ sở)</p>\r\n\r\n<p><strong>- Chủ đầu tư</strong>: C&ocirc;ng ty cổ phần S&ocirc;ng Đ&agrave; 6</p>\r\n\r\n<p><strong>- Tổ chức thực hiện dự &aacute;n</strong>: Ban quản l&yacute; dự &aacute;n &ndash; C&ocirc;ng ty CP S&ocirc;ng Đ&agrave; 6</p>\r\n\r\n<p><strong>- Địa điểm x&acirc;y dựng</strong>: Khu đất x&acirc;y dựng nằm trong địa giới h&agrave;nh ch&iacute;nh tr&ecirc;n l&ocirc; đất To&agrave; nh&agrave; cao tầng C&ocirc;ng tr&igrave;nh hỗn hợp Thương mại kết hợp nh&agrave; ở - Dự &aacute;n Khu nh&agrave; ở Văn Kh&ecirc;, thuộc địa phận x&atilde; Văn Kh&ecirc; quận H&agrave; Đ&ocirc;ng th&agrave;nh phố H&agrave; Nội.</p>\r\n\r\n<p><strong>- Diện t&iacute;ch sử dụng đất</strong>: 2.163 m<sup>2</sup>&nbsp;; DT x&acirc;y dựng: 860 m2; DT s&agrave;n: 7600 m2</p>\r\n\r\n<p><strong>- Tổ chức thực hiện khảo s&aacute;t ĐCCT</strong>: C&ocirc;ng ty Kiến tr&uacute;c c&ocirc;ng tr&igrave;nh ACO.</p>\r\n\r\n<p><strong>- Tổ chức tư vấn thiết kế</strong>: C&ocirc;ng ty cổ phần Kiến tr&uacute;c Việt</p>\r\n\r\n<p><strong>- Tổ chức thẩm tra</strong>: C&ocirc;ng ty tư vấn Đại học XD (CCU)</p>\r\n\r\n<p><strong>- Tổ chức thẩm định</strong>: Ph&ograve;ng KT-TC-AT C&ocirc;ng ty CP S&ocirc;ng Đ&agrave; 6.</p>\r\n\r\n<p>-&nbsp;<strong>Khởi c&ocirc;ng</strong>: Th&aacute;ng 12/2008</p>\r\n\r\n<p>-&nbsp;<strong>Ho&agrave;n th&agrave;nh</strong>: Th&aacute;ng 05/2011</p>\r\n\r\n<p><strong><em>- Cấp c&ocirc;ng tr&igrave;nh:&nbsp;</em></strong>Cấp II.</p>\r\n\r\n<p><img src="http://songda6.com.vn/uploads/project/Tru-so-Song-Da6.jpg" /></p>\r\n', '26s32m23h-03062017-songda6.jpg', '2017-06-03', 0, 0, 1, 'cong-trinh-hon-hop-thuong-mai-ket-hop-nha-o-tm'),
(43, 'CÔNG TRÌNH THỦY ĐIỆN SÔNG LÔ 2', '<p>C&Ocirc;NG TR&Igrave;NH THỦY ĐIỆN S&Ocirc;NG L&Ocirc; 2</p>\r\n', '<h1>C&Ocirc;NG TR&Igrave;NH THỦY ĐIỆN S&Ocirc;NG L&Ocirc; 2</h1>\r\n\r\n<p>C&ocirc;ng suất 28 MW<br />\r\n<strong>Chủ đầu tư</strong>: C&ocirc;ng ty TNHH Thanh B&igrave;nh<br />\r\n<strong>Thời gian thi c&ocirc;ng</strong>: 2015 - 2018<br />\r\n<strong>Loại đập</strong>: Đập b&ecirc; t&ocirc;ng trọng lực<br />\r\n<strong>Chiều d&agrave;i đập</strong>: 173.20 m<br />\r\n<strong>Chiều cao đập</strong>: 36.2 m<br />\r\n<strong>Số tổ m&aacute;y</strong>: 2 tổ m&aacute;y<br />\r\n<strong>Diện t&iacute;ch lưu vực</strong>: 8.330 Km2<br />\r\n<strong>Khối lượng đ&agrave;o đắp</strong>: 294.140 m3<br />\r\n<strong>Đổ b&ecirc; t&ocirc;ng</strong>: 61.520 m3<br />\r\n<strong>Dung t&iacute;ch hồ chứa</strong>: 9.298 triệu m3 nước<br />\r\n<strong>Tổng mức đầu tư</strong>: 898 tỷ VNĐ<br />\r\n<strong>Gi&aacute; trị hợp đồng của S&ocirc;ng Đ&agrave; 6</strong>: 251,81 tỷ VNĐ</p>\r\n\r\n<p><img src="http://songda6.com.vn/uploads/project/thuydiensonglo21.jpg" /></p>\r\n', '08s34m23h-03062017-small_thuydiensonglo21.jpg', '2017-06-02', 0, 0, 1, 'cong-trinh-thuy-dien-song-lo-2');
INSERT INTO `news` (`id`, `title`, `description`, `content`, `images`, `posted_date`, `hot`, `view`, `status`, `slug`) VALUES
(44, 'CÔNG TRÌNH THỦY ĐIỆN ĐỒNG NAI 5', '<p>C&Ocirc;NG TR&Igrave;NH THỦY ĐIỆN ĐỒNG NAI 5</p>\r\n', '<h1>C&Ocirc;NG TR&Igrave;NH THỦY ĐIỆN ĐỒNG NAI 5</h1>\r\n\r\n<p><strong>C&ocirc;ng suất</strong>: 150 MW<br />\r\n<strong>Chủ đầu tư</strong>: Tổng c&ocirc;ng ty điện lực Vinacomin<br />\r\n<strong>Thời gian thi c&ocirc;ng</strong>: 4 năm<br />\r\n<strong>Loại đập</strong>: Đập b&ecirc; t&ocirc;ng đầm lăn<br />\r\n<strong>Chiều d&agrave;i đập</strong>: 471 m<br />\r\n<strong>Chiều cao đập</strong>: 72 m<br />\r\n<strong>Dung t&iacute;ch hồ chứa nước</strong>: 106,33 triệu m3 nước.<br />\r\n<strong>Số tổ m&aacute;y</strong>: 2 tổ m&aacute;y<br />\r\n<strong>Khối lượng b&ecirc; t&ocirc;ng</strong>: 625.234 m3<br />\r\n<strong>Diện t&iacute;ch lưu vực</strong>: 6.144 km2<br />\r\n<strong>Tổng mức đầu tư</strong>: 5.209,57 tỷ VNĐ<br />\r\n<strong>Gi&aacute; trị hợp đồng của S&ocirc;ng Đ&agrave; 6</strong>: 514,05 tỷ&nbsp;VNĐ</p>\r\n\r\n<p><img src="http://songda6.com.vn/uploads/project/Cong%20trinh%20thuy%20dien%20Dong%20Nai%205.jpg" /></p>\r\n', '09s35m23h-03062017-small_Cong trinh thuy dien Dong Nai 5.jpg', '2017-05-19', 0, 0, 1, 'cong-trinh-thuy-dien-dong-nai-5'),
(45, 'Công trình thủy điện Sơn La', '<p>C&ocirc;ng tr&igrave;nh thủy điện Sơn La</p>\r\n', '<p>&nbsp;</p>\r\n\r\n<p><strong>Sơn La l&agrave; nh&agrave; m&aacute;y thủy điện lớn nhất Đ&ocirc;ng Nam &Aacute;</strong><br />\r\nDự &aacute;n thủy điện Sơn La l&agrave; một trong những c&ocirc;ng t&igrave;nh trọng điểm quốc gia, đặc biệt về chất lượng, tiến độ v&agrave; an to&agrave;n lao động.<br />\r\n<strong>Th&ocirc;ng tin ch&iacute;nh:</strong><br />\r\n- Chủ đầu tư: EVN<br />\r\n- Địa điểm x&acirc;y dựng: X&atilde; &Iacute;t Ong, huyện Mường La, tỉnh Sơn La<br />\r\n- Tổng mức đầu tư ( ước t&iacute;nh): 60.195,928 tỷ đồng<br />\r\n- Loại đập: B&ecirc; t&ocirc;ng đầm lăn<br />\r\n- Thời gian thực hiện: 2005 - 2012<br />\r\n- Số tổ m&aacute;y: 06 tổ m&aacute;y<br />\r\n- C&ocirc;ng suất lắp m&aacute;y Nlm= 2400 MW<br />\r\n- Điện lượng trung b&igrave;nh năm: 9.429 triệu KW</p>\r\n\r\n<p><img src="http://songda6.com.vn/uploads/project/Ngoc_Ha_1.jpg" /></p>\r\n', '21s36m23h-03062017-ThuyDienSonLa2010.jpg', '2017-05-25', 0, 0, 1, 'cong-trinh-thuy-dien-son-la'),
(46, 'Công trình thủy điện Sê San 4', '<p>C&ocirc;ng tr&igrave;nh thủy điện S&ecirc; San 4</p>\r\n', '<p><em>C&ocirc;ng suất 360 M</em></p>\r\n\r\n<p><strong>Chủ đầu tư</strong>: Ban quản l&iacute; thuỷ điện 4<br />\r\n<strong>Gi&aacute; trị hợp đồng với SD6</strong>: 686,6 tỷ đồng<br />\r\n<strong>Thời gian thi c&ocirc;ng</strong>: 5 năm<br />\r\n<strong>Chiều d&agrave;i đập theo đỉnh</strong>: 850 m<br />\r\n<strong>Chiều cao đập lớn nhất</strong>: 74,13 m<br />\r\n<strong>Chiều rộng đỉnh đập</strong>: 10 m<br />\r\n<strong>Mực nước d&acirc;ng trung b&igrave;nh</strong>: 36 m<br />\r\n<strong>Dung t&iacute;ch hồ chứa nước</strong>: 893 triệu m3<br />\r\n<strong>Số tổ m&aacute;y</strong>: 3 tổ m&aacute;y<br />\r\n<strong>Khối lượng đ&agrave;o đắp</strong>: 2 triệu m3 đất đ&aacute;<br />\r\n<strong>Đổ b&ecirc; t&ocirc;ng</strong>: 1,42.106 m3<br />\r\n<strong>Khoan phun</strong>: 53,79.103 m</p>\r\n\r\n<p><img src="http://songda6.com.vn/uploads/project/thuydiensedan41.jpg" /></p>\r\n', '25s37m23h-03062017-small_1435830062.jpg', '2017-05-02', 0, 0, 1, 'cong-trinh-thuy-dien-se-san-4'),
(47, 'Công trình thủy điện Hòa Bình', '<p>C&ocirc;ng tr&igrave;nh thủy điện H&ograve;a B&igrave;nh</p>\r\n', '<h1>C&Ocirc;NG TR&Igrave;NH THỦY ĐIỆN H&Ograve;A B&Igrave;NH</h1>\r\n\r\n<p><em>C&ocirc;ng suất 1.920 MW</em></p>\r\n\r\n<p><strong>Sản lượng điện h&agrave;ng năm</strong>: 8,16 tỷ kw/h<br />\r\n<strong>Chủ đầu tư</strong>: Tập đo&agrave;n Điện lực việt nam<br />\r\n<strong>Thời gian thi c&ocirc;ng</strong>: 1979 - 1996<br />\r\n<strong>Loại đập</strong>: Đ&aacute; đổ c&oacute; l&otilde;i s&eacute;t<br />\r\n<strong>Chiều d&agrave;i đập</strong>: 734 m<br />\r\n<strong>Chiều cao đập</strong>: 128 m<br />\r\n<strong>Dung t&iacute;ch hồ chứa nước</strong>: 9 tỷ m3<br />\r\n<strong>Số tổ m&aacute;y</strong>: 8 tổ m&aacute;y<br />\r\n<strong>Khối lượng đ&agrave;o đắp đất đ&aacute;</strong>: 50.000.000 m3<br />\r\n<strong>Đổ b&ecirc; t&ocirc;ng</strong>: 1.899.000 m3<br />\r\n<strong>Khoan phun</strong>: 205.000 m<br />\r\n<strong>Lắp đặt thiết bị kim loại</strong>: 46.721 tấn</p>\r\n\r\n<p><img src="http://songda6.com.vn/uploads/project/1435830062.jpg" /></p>\r\n', '55s38m23h-03062017-small_thuydiensedan41.jpg', '2017-06-03', 0, 0, 1, 'cong-trinh-thuy-dien-hoa-binh'),
(48, 'Công trình thủy điện Hòa Bình', '<p>C&ocirc;ng tr&igrave;nh thủy điện H&ograve;a B&igrave;nh</p>\r\n', '<h1>C&Ocirc;NG TR&Igrave;NH THỦY ĐIỆN H&Ograve;A B&Igrave;NH</h1>\r\n\r\n<p><em>C&ocirc;ng suất 1.920 MW</em></p>\r\n\r\n<p><strong>Sản lượng điện h&agrave;ng năm</strong>: 8,16 tỷ kw/h<br />\r\n<strong>Chủ đầu tư</strong>: Tập đo&agrave;n Điện lực việt nam<br />\r\n<strong>Thời gian thi c&ocirc;ng</strong>: 1979 - 1996<br />\r\n<strong>Loại đập</strong>: Đ&aacute; đổ c&oacute; l&otilde;i s&eacute;t<br />\r\n<strong>Chiều d&agrave;i đập</strong>: 734 m<br />\r\n<strong>Chiều cao đập</strong>: 128 m<br />\r\n<strong>Dung t&iacute;ch hồ chứa nước</strong>: 9 tỷ m3<br />\r\n<strong>Số tổ m&aacute;y</strong>: 8 tổ m&aacute;y<br />\r\n<strong>Khối lượng đ&agrave;o đắp đất đ&aacute;</strong>: 50.000.000 m3<br />\r\n<strong>Đổ b&ecirc; t&ocirc;ng</strong>: 1.899.000 m3<br />\r\n<strong>Khoan phun</strong>: 205.000 m<br />\r\n<strong>Lắp đặt thiết bị kim loại</strong>: 46.721 tấn</p>\r\n\r\n<p><img src="http://songda6.com.vn/uploads/project/1435830062.jpg" /></p>\r\n', '17s39m23h-03062017-small_thuydiensedan41.jpg', '2017-06-03', 0, 0, 1, 'cong-trinh-thuy-dien-hoa-binh'),
(49, 'Công trình tòa nhà quốc hội', '<p>C&ocirc;ng tr&igrave;nh t&ograve;a nh&agrave; quốc hội</p>\r\n', '<h1>C&Ocirc;NG TR&Igrave;NH T&Ograve;A NH&Agrave; QUỐC HỘI</h1>\r\n\r\n<p><strong>Th&ocirc;ng tin ch&iacute;nh</strong><br />\r\n<br />\r\n- Chủ đầu tư: Bộ X&acirc;y dựng<br />\r\n<br />\r\n- Tổng mức đầu tư: 6.838 &nbsp;tỷ VNĐ<br />\r\n&nbsp;<br />\r\n- Địa điểm x&acirc;y dựng: Quận Ba Đ&igrave;nh, H&agrave; Nội<br />\r\n<br />\r\n- Thời gian thi c&ocirc;ng: 2009 -2014<br />\r\n<br />\r\n<strong>C&ocirc;ng t&aacute;c thi c&ocirc;ng của S&ocirc;ng Đ&agrave; 6:&nbsp;</strong><br />\r\n<br />\r\n- Thi c&ocirc;ng c&aacute;c hạng mục: Hầm, m&oacute;ng, to&agrave;n bộ phần th&acirc;n v&agrave; c&ocirc;ng t&aacute;c ho&agrave;n thiện c&ocirc;ng tr&igrave;nh</p>\r\n\r\n<p><img src="http://songda6.com.vn/uploads/project/nhaquochoi21435828855.jpg" /></p>\r\n', '04s41m23h-03062017-small_1435828855.jpg', '2017-06-01', 0, 0, 1, 'cong-trinh-toa-nha-quoc-hoi'),
(50, 'Giới thiệu chung', '<p>Giới thiệu chung</p>\r\n', '<p><strong>Tổng quan về c&ocirc;ng ty</strong><br />\r\n&middot;&nbsp; T&ecirc;n c&ocirc;ng ty: C&ocirc;ng ty cổ phần S&ocirc;ng Đ&agrave; 6<br />\r\n&middot;&nbsp; T&ecirc;n tiếng Anh: Song Da 6 Joint stock company<br />\r\n&middot;&nbsp; Trụ sở ch&iacute;nh: To&agrave; nh&agrave; TM, Khu đ&ocirc; thị Văn Kh&ecirc;, Phường La Kh&ecirc;,&nbsp;<br />\r\n&nbsp;Quận H&agrave; Đ&ocirc;ng, Th&agrave;nh phố H&agrave; Nội<br />\r\n&middot;&nbsp; Tel: 04.2216 9622<br />\r\n&middot;&nbsp; Fax: 04.2225 3366<br />\r\n&middot;&nbsp; Website: www.songda6.com.vn<br />\r\n&middot;&nbsp; Email: congtycophansongda6@songda6.com.vn<br />\r\n&middot;&nbsp; M&atilde; số thuế: 4400135552<br />\r\n&middot;&nbsp; vốn điều lệ: 347.716.110.000 vnđ</p>\r\n\r\n<p><img src="http://songda6.com.vn/editor/elfinder/files/HinhCongty/songda6.jpg" /></p>\r\n\r\n<p><strong>Tầm nh&igrave;n 2025</strong><br />\r\nX&acirc;y dựng S&ocirc;ng Đ&agrave; 6 trở th&agrave;nh nh&agrave; thầu x&acirc;y dựng chuy&ecirc;n nghiệp, đủ năng lực l&agrave;m Tổng thầu x&acirc;y dựng hoặc Tổng thầu EPC c&aacute;c dự &aacute;n Thủy điện, nhiệt điện, giao th&ocirc;ng đ&ocirc; thị, d&acirc;n dụng v&agrave; c&ocirc;ng nghiệp, tiến tới l&agrave;m chủ c&ocirc;ng nghệ x&acirc;y dựng nh&agrave; m&aacute;y Điện hạt nh&acirc;n; m&ocirc; h&igrave;nh quản trị ph&ugrave; hợp với th&ocirc;ng lệ Quốc tế, nh&acirc;n lực chất lượng cao, c&ocirc;ng nghệ x&acirc;y dựng hiện đại, đủ năng lực hội nhập với thị trường quốc tế.</p>\r\n\r\n<p><strong>Tuy&ecirc;n ng&ocirc;n sứ mệnh</strong><br />\r\nĐối với kh&aacute;ch h&agrave;ng : S&ocirc;ng Đ&agrave; 6 l&agrave; người bạn đồng h&agrave;nh tin cậy v&agrave; l&acirc;u d&agrave;i của qu&yacute; kh&aacute;ch h&agrave;ng tr&ecirc;n con đường ph&aacute;t triển; lu&ocirc;n cam kết cung cấp cho qu&yacute; kh&aacute;ch h&agrave;ng c&aacute;c sản phẩm x&acirc;y dựng chất lượng cao bền vững c&ugrave;ng năm th&aacute;ng v&agrave; tiến độ tốt nhất với mức gi&aacute; ph&ugrave; hợp thị trường.<br />\r\nĐối với cổ đ&ocirc;ng : L&agrave; một tổ chức kinh tế hoạt động bền vững v&agrave; hiệu quả cao, đảm bảo lợi &iacute;ch cao v&agrave; l&acirc;u d&agrave;i cho cổ đ&ocirc;ng.&nbsp;<br />\r\nĐối với người lao động : Tạo m&ocirc;i trường l&agrave;m việc th&acirc;n thiện, chuy&ecirc;n nghiệp, an to&agrave;n, đảm bảo đời sống vật chất v&agrave; tinh thần; tạo động lực v&agrave; m&ocirc;i trường để CBCNV&nbsp;ph&aacute;t huy tối đa năng lực bản th&acirc;n đ&oacute;ng g&oacute;p x&acirc;y dựng C&ocirc;ng ty.<br />\r\nĐối với x&atilde; hội: Đồng h&agrave;nh c&ugrave;ng sự ph&aacute;t triển của Tổng c&ocirc;ng ty S&ocirc;ng Đ&agrave;, v&igrave; sự nghiệp hiện đại ho&aacute; của đất nước, đồng thời thực hiện đầy đủ nghĩa vụ nộp ng&acirc;n s&aacute;ch với Nh&agrave; nước, t&iacute;ch cực tham gia c&aacute;c hoạt động v&igrave; cộng đồng; cam kết mang đến những sản phẩm x&acirc;y dựng th&acirc;n thiện với m&ocirc;i trường</p>\r\n\r\n<p><strong>Gi&aacute; trị cốt l&otilde;i</strong><br />\r\nSự chuy&ecirc;n nghiệp trong x&acirc;y dựng với m&ocirc; h&igrave;nh quản trị v&agrave; c&ocirc;ng nghệ x&acirc;y dựng hiện đại để tạo n&ecirc;n c&ocirc;ng tr&igrave;nh chất lượng cao, tiến độ tốt nhất với mức gi&aacute; hợp l&yacute; l&agrave; gi&aacute; trị cốt l&otilde;i của S&ocirc;ng Đ&agrave; 6.</p>\r\n', '09s42m23h-03062017-songda6.jpg', '2017-05-26', 0, 0, 1, 'gioi-thieu-chung'),
(51, 'Lịch sử phát triển', '<p>Lịch sử ph&aacute;t triển</p>\r\n', '<p>Giai đoạn từ 01/05/1983 đến năm 1990 (Trụ sở C&ocirc;ng ty: Tại thị x&atilde; Ho&agrave; B&igrave;nh - tỉnh Ho&agrave; B&igrave;nh).</p>\r\n\r\n<p>C&ocirc;ng ty cổ phần S&ocirc;ng Đ&agrave; 6, tiền th&acirc;n l&agrave; C&ocirc;ng ty x&acirc;y dựng Thuỷ C&ocirc;ng. Đơn vị th&agrave;nh vi&ecirc;n của Tổng C&ocirc;ng ty S&ocirc;ng Đ&agrave;, th&agrave;nh lập ng&agrave;y 01/05/1983. C&ocirc;ng ty x&acirc;y dựng Thuỷ C&ocirc;ng được Bộ x&acirc;y dựng Quyết định th&agrave;nh lập để tham gia thi c&ocirc;ng c&aacute;c hạng mục c&ocirc;ng tr&igrave;nh thuỷ c&ocirc;ng chuy&ecirc;n ng&agrave;nh của dự &aacute;n thuỷ điện Ho&agrave; B&igrave;nh, c&ocirc;ng tr&igrave;nh thế kỷ của dất nước. Về quy m&ocirc; C&ocirc;ng ty trong giai đoạn n&agrave;y: C&ocirc;ng ty c&oacute; 6 X&iacute; nghiệp trực thuộc, một Tổng đội m&aacute;y bơm b&ecirc; t&ocirc;ng, một sưởng sửa chữa cơ kh&iacute;, với 10 ph&ograve;ng nghiệp vụ. Lực lượng lao động tại thời kỳ cao điểm đến hơn 4.000 người. C&aacute;c hạng mục c&ocirc;ng tr&igrave;nh ch&iacute;nh của dự &aacute;n thuỷ điện Ho&agrave; B&igrave;nh C&ocirc;ng ty đ&atilde; trực tiếp thi c&ocirc;ng đều đảm bảo chất lượng, tiến độ an to&agrave;n l&agrave;: Cửa nhận nước, Đập tr&agrave;n, Hầm dẫn nước, Hầm gian biến thế, Hầm gian m&aacute;y, Hầm giao th&ocirc;ng; Khối lượng b&ecirc; t&ocirc;ng đ&atilde; thi c&ocirc;ng l&agrave; 1.368.380 m<sup>3</sup>, gia cố lắp đặt 41.421 tấn th&eacute;p c&aacute;c loại.</p>\r\n\r\n<p>Giai đoạn từ năm 1991 đến năm 1995 (Trụ sở c&ocirc;ng ty : Tại thị x&atilde; Ho&agrave; B&igrave;nh - tỉnh Ho&agrave; B&igrave;nh).</p>\r\n\r\n<p>Lần lượt c&aacute;c tổ m&aacute;y của thuỷ điện Ho&agrave; B&igrave;nh đi v&agrave;o hoạt động, đ&aacute;nh dấu thời điểm kết th&uacute;c x&acirc;y dựng c&ocirc;ng tr&igrave;nh thế kỷ. Đồng thời cũng l&agrave; thời kỳ thiếu việc l&agrave;m trầm trọng cho gần 30.000 lao động của c&ocirc;ng trường. Thời kỳ n&agrave;y C&ocirc;ng ty cũng như nhiều doanh nghiệp kh&aacute;c trong Tổng c&ocirc;ng ty S&ocirc;ng Đ&agrave; gặp kh&ocirc;ng &iacute;t kh&oacute; khăn về việc l&agrave;m, do chưa thiết ứng với cơ chế quản l&yacute; kinh tế thị trường. Thu nhập v&agrave; đời sống của người lao động bị giảm s&uacute;t. Nhiệm vụ ch&iacute;nh của C&ocirc;ng ty giai đoạn n&agrave;y l&agrave; thi c&ocirc;ng c&aacute;c phần việc c&ograve;n lại của dự &aacute;n thuỷ điện Ho&agrave; B&igrave;nh; Tham gia thi c&ocirc;ng mở rộng dự &aacute;n thuỷ điện S&ecirc;LaBăm thuộc C&ocirc;ng ho&agrave; d&acirc;n chủ nh&acirc;n d&acirc;n L&agrave;o, nh&agrave; m&aacute;y Xi măng S&ocirc;ng Đ&agrave;, nh&agrave; m&aacute;y m&iacute;a đường Ho&agrave; B&igrave;nh, nh&agrave; m&aacute;y Xi măng Lương sơn v v, để c&oacute; việc l&agrave;m cho một phần c&aacute;n bộ c&ocirc;ng nh&acirc;n vi&ecirc;n của C&ocirc;ng ty.</p>\r\n\r\n<p>Giai đoạn từ năm 1996 đến năm 1999 (Trụ sở C&ocirc;ng ty: Tại huyện S&ocirc;ng hinh - tỉnh Ph&uacute; Y&ecirc;n).</p>\r\n\r\n<p>C&ocirc;ng ty đổi t&ecirc;n từ C&ocirc;ng ty x&acirc;y dựng Thuỷ C&ocirc;ng th&agrave;nh C&ocirc;ng ty x&acirc;y dựng S&ocirc;ng Đ&agrave; 6 v&agrave; chuyển trụ sở từ thị x&atilde; Ho&agrave; B&igrave;nh - tỉnh Ho&agrave; B&igrave;nh v&agrave;o huyện S&ocirc;ng Hinh - tỉnh Ph&uacute; Y&ecirc;n để tham gia x&acirc;y dựng dự &aacute;n thuỷ điện S&ocirc;ng Hinh. Nhiệm vụ ch&iacute;nh của C&ocirc;ng ty trong thời kỳ n&agrave;y l&agrave; x&acirc;y dựng tuyến năng lượng nh&agrave; m&aacute;y thuỷ điện S&ocirc;ng Hinh, bao gồm c&aacute;c hạng mục: Cửa nhận nước, Hầm dẫn nước, Tuyến ống &aacute;p lực, nh&agrave; m&aacute;y thuỷ điện, K&ecirc;nh dẫn nước v&agrave;o, K&ecirc;nh dẫn nước ra, Trạm biến thế điện, Th&aacute;p điều &aacute;p v v. Gi&aacute; trị sản lượng thực hiện 355.5 tỷ đồng; Khối lượng khoan nổ đ&aacute; hầm v&aacute; hở l&agrave; 9.362.880 m<sup>3</sup>, thi c&ocirc;ng b&ecirc; t&ocirc;ng 74.557 m<sup>3</sup>. Về quy m&ocirc;: C&ocirc;ng ty c&oacute; 6 ph&ograve;ng nghiệp vụ, 3 X&iacute; nghiệp trực thuộc, tổng số c&aacute;n bộ c&ocirc;ng nh&acirc;n vi&ecirc;n b&igrave;nh qu&acirc;n l&agrave; 1400 người.</p>\r\n\r\n<p>Giai đoạn từ năm 2000 đến năm 2005 (Trụ sở C&ocirc;ng ty: Tại huyện S&ocirc;ng Hinh - tỉnh Ph&uacute; Y&ecirc;n) th&aacute;ng 4/2002 C&ocirc;ng ty chuyển trụ sở về c&ocirc;ng trường thuỷ điện S&ecirc;San 3A x&atilde; IaKhai - huyện IaGrai - tỉnh Gia Lai.</p>\r\n\r\n<p>Nhiệm vụ ch&iacute;nh: Tham gia thi c&ocirc;ng c&aacute;c hạng mục c&ocirc;ng tr&igrave;nh ch&iacute;nh của dự &aacute;n thuỷ điện Cần Đơn - tỉnh B&igrave;nh Phước, dự &aacute;n do Tổng c&ocirc;ng ty S&ocirc;ng Đ&agrave; đầu tư theo h&igrave;nh thức BOT. Tham gia x&acirc;y dựng đường Hồ Ch&iacute; Minh đoạn Aro&agrave;ng Thừa Thi&ecirc;n Huế đến At&eacute;p tỉnh Quảng Nam. Tham gia x&acirc;y dựng c&aacute;c hạng mục c&ocirc;ng tr&igrave;nh ch&iacute;nh dự &aacute;n thuỷ điện S&ecirc;San 3A nằm tr&ecirc;n s&ocirc;ng S&ecirc;San, bậc thang dưới của thuỷ điện S&ecirc;San 3, thuộc địa b&agrave;n 2 tỉnh Gia Lai v&agrave; Kon Tum. Tham gia chuẩn bị c&ocirc;ng trường thuỷ điện S&ecirc;San 4 bậc thang dưới của thuỷ điện S&ecirc;San 3A. Quy m&ocirc;: C&ocirc;ng ty c&oacute; 5 ph&ograve;ng nghiệp vụ, 6 X&iacute; nghiệp trực thuộc, tổng số c&aacute;n bộ c&ocirc;ng nh&acirc;n vi&ecirc;n b&igrave;nh qu&acirc;n l&agrave; 1.700 người. Th&aacute;ng 12/2003 C&ocirc;ng ty cổ phần ho&aacute; X&iacute; nghiệp S&ocirc;ng Đ&agrave; 6.06 trực thuộc C&ocirc;ng ty th&agrave;nh C&ocirc;ng ty cổ phần S&ocirc;ng Đ&agrave; 6.06. Th&aacute;ng 9/2004 C&ocirc;ng ty cổ phần ho&aacute; X&iacute; nghiệp S&ocirc;ng Đ&agrave; 6.04 trực thuộc C&ocirc;ng ty th&agrave;nh C&ocirc;ng ty cổ phần S&ocirc;ng Đ&agrave; 6.04.</p>\r\n\r\n<p>Giai đoạn từ 01/01/2006 đến nay: C&ocirc;ng ty đ&atilde; cổ phần ho&aacute; v&agrave; chuyển đổi th&agrave;nh C&ocirc;ng ty cổ phần từ 01/01/2006; giấy chứng nhận đăng k&yacute; kinh doanh 3903400072 do sở kế hoạch tỉnh Gia Lai cấp ng&agrave;y 03/01/2006. Trụ sở C&ocirc;ng ty: T&ograve;a nh&agrave; TM khu đ&ocirc; thị Văn Kh&ecirc; - phường La Kh&ecirc; - quận H&agrave; Đ&ocirc;ng, TP H&agrave; Nội.</p>\r\n\r\n<p>Nhiệm vụ ch&iacute;nh của C&ocirc;ng ty: Thi c&ocirc;ng c&aacute;c hạng mục c&ocirc;ng tr&igrave;nh ch&iacute;nh của dự &aacute;n thuỷ điện S&ecirc;San 4,S&ecirc; San 4a, thủy điện Hủa Na, thủy điện Sơn La, thủy điện Nậm Chiến, thủy điện Huội Quảng...Đắp đập, thi c&ocirc;ng b&ecirc; t&ocirc;ng đầm lăn, b&ecirc; t&ocirc;ng cửa nhận nước, đập tr&agrave;n nh&agrave; m&aacute;y, k&ecirc;nh dẫn nước ra, sản xuất đ&aacute; x&acirc;y dựng, sản xuất b&ecirc; t&ocirc;ng; Tham gia thi c&ocirc;ng cầu đường, thi c&ocirc;ng c&aacute;c hạng mục c&ocirc;ng tr&igrave;nh ch&iacute;nh v&agrave; khai th&aacute;c sản xuất đ&aacute; x&acirc;y dựng dự &aacute;n thuỷ điện S&ecirc;KaMan 3 thự&ocirc;c nước Cộng ho&agrave; d&acirc;n chủ nh&acirc;n d&acirc;n L&agrave;o bao gồm c&ocirc;ng t&aacute;c thi c&ocirc;ng đất, đ&aacute;, b&ecirc; t&ocirc;ng c&aacute;c hạng mục c&ocirc;ng tr&igrave;nh ch&iacute;nh cửa nhận nước, đập tr&agrave;n, đập d&acirc;ng, hầm dẫn nước, nh&agrave; m&aacute;y thuỷ điện, sản xuất vật liệu đ&aacute;, b&ecirc; t&ocirc;ng v&agrave; chuẩn bị đầu tư một số dự &aacute;n như: X&acirc;y dựng khu chung cư CT2 , t&ograve;a nh&agrave; thương mại hỗn hợp TM tại khu đ&ocirc; thị Văn Kh&ecirc; H&agrave; Đ&ocirc;ng - TP H&agrave; Nội, triển khai x&acirc;y dựng dự &aacute;n khu nh&agrave; ở cao cấp HH6 Nam An Kh&aacute;nh - H&agrave; Nội, Triển khai x&acirc;y dựng T&ograve;a nh&agrave; Quốc Hội v&agrave; những dự &aacute;n thuỷ điện, x&acirc;y dựng d&acirc;n dụng, x&acirc;y dựng c&ocirc;ng nghiệp, du lich...</p>\r\n', '', '2017-05-31', 0, 0, 1, 'lich-su-phat-trien'),
(52, 'Sơ đồ tổ chức', '<p>Sơ đồ tổ chức</p>\r\n', '<p><img src="http://songda6.com.vn/editor/elfinder/files/HinhCongty/So%20do%20to%20chuc.jpg" /></p>\r\n', '', '2017-06-03', 0, 0, 1, 'so-do-to-chuc'),
(53, 'Xây dựng nhiệt điện', '<p>X&acirc;y dựng nhiệt điện</p>\r\n', '', '51s55m15h-04062017-1435831117.png', '2017-06-04', 0, 0, 1, 'xay-dung-nhiet-dien'),
(54, 'Xây dựng thủy điện', '<p>X&acirc;y dựng thủy điện</p>\r\n', '', '12s56m15h-04062017-1435832153.png', '2017-06-04', 0, 0, 1, 'xay-dung-thuy-dien'),
(55, 'Đầu tư dự án', '<p>Đầu tư dự &aacute;n</p>\r\n', '', '30s56m15h-04062017-dau_tu_du_an1443601276.png', '2017-06-04', 0, 0, 1, 'dau-tu-du-an'),
(56, 'Xây dựng dân dụng - công nghiệp', '<p>X&acirc;y dựng d&acirc;n dụng - c&ocirc;ng nghiệp</p>\r\n', '', '20s57m15h-04062017-1435831156.png', '2017-06-04', 0, 0, 1, 'xay-dung-dan-dung-cong-nghiep');

-- --------------------------------------------------------

--
-- Table structure for table `page_info`
--

CREATE TABLE `page_info` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(500) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `fax` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `page_info`
--

INSERT INTO `page_info` (`id`, `title`, `description`, `email`, `address`, `tel`, `fax`) VALUES
(1, 'Công ty cổ phần sông đà 6', 'đơn vị anh hùng lao động', 'congtycophansongda6@songda6.com.vn', 'Nhà TM, Khu đô thị Văn Khê, Phường La Khê, Quận Hà Đông, TP Hà Nội', '(+84-4) 22169622', '(+84-4) 22253366');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'Admin'),
(2, 'Quản lý'),
(3, 'Biên tập viên'),
(4, 'Tác giả'),
(5, 'Cộng tác viên');

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `id` int(11) NOT NULL,
  `images` varchar(500) NOT NULL,
  `content` text,
  `parent` int(11) NOT NULL,
  `position` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`id`, `images`, `content`, `parent`, `position`, `status`) VALUES
(1, '01s22m14h01062017-toanhaquochoi.jpg', 'Tòa nhà quốc hội', 0, 0, 1),
(2, '00s24m14h01062017-thuydiensesan4.jpg', 'Thủy điện Sê san', 0, 0, 1),
(3, '17s24m14h01062017-contrinhthuydiensonla.jpg', 'Công trình thủy điện Sơn La', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `role_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `role_id`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@admin.com', '$2y$10$JzPZNEg8lAfuV5dC6PybbeXSTbake.5MphB3BQgx78QvVfJ2BfV0K', 'f31nMmnWw8JzZpwnBS8cHPJhQSflm2ETpGEGXkYRHbA1rQlWUzTmogEY1sgm', 1, '2017-05-10 21:16:14', '2017-05-30 02:27:10'),
(2, '1', '1@gmail.com', '$2y$10$bV2EMLEog7Y8coy8/C0yRekX/C421BQHJPf/Fp6v2bSoiYtsiF/fO', 'tilpLAyUi16GeOC2EL74cgYXoZ8fXvtvj8GndDf0nfnJcsuUMN1k8b92v721', 2, '2017-05-28 10:38:38', '2017-05-29 02:40:59'),
(4, '123', '123@123', '$2y$10$0nStRE4Np9nKbQszjF4Z.OU.ecuua3Onr.LCPmgvUZMDf0sxORkMG', NULL, 4, '2017-05-28 10:44:49', '2017-05-29 16:12:11'),
(5, '321', '321@321', '$2y$10$iqeO46nWx7B5U9jbcAiwweEcFm6IRGz6T0s1gIaOXw080zEemtESK', NULL, 5, '2017-05-28 10:45:27', '2017-05-28 16:15:02'),
(6, '22', '22@gmail.com', '$2y$10$x8lFipA7kjjHzsLOiTZkOehPNiA2NsgXJKV8X2ShctquBU9OszgQK', NULL, 4, '2017-05-28 10:46:38', '2017-05-28 16:14:57');

-- --------------------------------------------------------

--
-- Table structure for table `user_access`
--

CREATE TABLE `user_access` (
  `id` int(11) NOT NULL,
  `day` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_online`
--

CREATE TABLE `user_online` (
  `time` int(15) NOT NULL,
  `session` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_online`
--

INSERT INTO `user_online` (`time`, `session`) VALUES
(1496635530, '9jk5ip2aht5er3pd2l1b1b7q41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category_news_details`
--
ALTER TABLE `category_news_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page_info`
--
ALTER TABLE `page_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `category_news_details`
--
ALTER TABLE `category_news_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `page_info`
--
ALTER TABLE `page_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
