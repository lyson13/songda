<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CateNews extends Model
{
    protected $table = 'category_news_details';
    public $timestamps = false;
    public function news()
    {
    	return $this->belongsTo('App\News');
    }
    public function category()
    {
    	return $this->belongsTo('App\Category');
    }
}
