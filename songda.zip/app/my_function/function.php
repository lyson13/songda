<?php 
	function MenuMulti($category,$parent ,$str='---| ',$select)
	{
		foreach ($category as $val) {
			$id = $val["id"];
			$ten= $val["name"];
			if ($val['parent'] == $parent) {
				// print_r($select);  exit();
				if ($select!=0 && $id == $select) {
					echo '<option value="'.$id.'" selected >'.$str." ".$ten.'</option>';
				}	else {
					echo '<option value="'.$id.'">'.$str." ".$ten.'</option>';
				}			
				MenuMulti($category,$id,$str.'- ',$select);
			}			
		}
	}
	//multi menu
	function echo_menu($menu_array) {
    foreach($menu_array as $menu) {
        echo "<li><a href='{$menu['link']}'>{$menu['titulo']}</a>";
        if(array_key_exists('children', $menu)) {
            echo '<ul>';
            echo_menu($menu['children']);
            echo '</ul>';
        }
        echo '</li>';
    }
}

// echo '<ul>';
// echo_menu($menu_array);
// echo '</ul>';
	
	
?>