<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class News extends Model
{
    protected $table = 'news';
    public $timestamps = false;
    public function category()
    {
    	return $this->belongstoMany('App\Category','category_news_details','news_id','category_id');
    }
}
