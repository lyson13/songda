<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserOnline extends Model
{
    protected $table = 'user_online';
    public $timestamps = false;
}
