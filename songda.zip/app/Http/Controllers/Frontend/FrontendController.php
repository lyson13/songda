<?php
namespace App\Http\Controllers\Frontend;
use Illuminate\Http\Request;
use App\Contact, App\User, App\UserOnline, App\Category, App\PageInfo, App\News, App\Slide, App\CateNews;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session, DB, View;

class FrontendController extends Controller
{
	public function __construct(){
        //count user online
        @session_start();
        $session_id = session_id();
        $time = time();
        $tgout = 600;
        $time_check = $time - $tgout;
        $check_session = UserOnline::where('session',$session_id)->count();
        if ($check_session == 0) {
            $user_online = new UserOnline();
            $user_online->session = $session_id;
            $user_online->time = $time;
            $user_online->save();
        }else{
            $user_online = UserOnline::where('session',$session_id)->first();
            DB::update("update user_online set time = '$time' where session = '$session_id' ");
        }
        DB::delete("delete from user_online where time < '$time_check' ");
        $count_user_online = UserOnline::all();

        //count access

        //datb
        $datb_sidebar_cate = CateNews::where('category_id','3')->get();

        //parent menu header
        $show_menu = Category::where('status','1')->where('parent','0')->orderBy('position','asc')->get();
        //sub menu

        //menu doc
        
        //page info
        $page_info = PageInfo::find('1');

        //slide
        $slide_top = Slide::where('status',1)->get()->toArray();

        view()->share('datb_sidebar_cate',$datb_sidebar_cate);
        view()->share('slide_top',$slide_top);
        view()->share('page_info',$page_info);
        view()->share('show_menu',$show_menu);
        view()->share('user_online',$count_user_online);
	}

    //home
    function home(){
        /*- - -du an tieu bieu- - - */
        $data['get_cate_datb'] = Category::where('id', '3')->first();
        $data['news_datb'] = CateNews::where('category_id','3')->take(7)->get();
        foreach ($data['news_datb'] as $value) {
            $item_datb[] = $value->news_id;
        }
        $data['get_datb'] = News::whereIn('id',$item_datb)->where('status','1')->get();


        /*- - -tin tuc su kien- - - */
        $data['get_cate_ttsk'] = Category::where('id', '2')->first();
        $data['news_ttsk'] = CateNews::where('category_id','2')->take(9)->get();
        foreach ($data['news_ttsk'] as $value) {
            $item_ttsk[] = $value->news_id;
        }
        $data['get_ttsk'] = News::whereIn('id',$item_ttsk)->where('status','1')->get();


        /*- - -linh vuc hoat dong- - - */
        $data['get_cate_lvhd'] = Category::where('id', '11')->first();
        $data['news_lvhd'] = CateNews::where('category_id', '11')->take(7)->get();
        foreach ($data['news_lvhd'] as $value) {
            $item_lvhd[] = $value->news_id;
        }
        $data['get_lvhd'] = News::whereIn('id',$item_lvhd)->where('status','1')->get();

        
        /*- - -gioi thieu- - - */
        $data['get_cate_gt'] = Category::where('id', '1')->first();
        $data['news_gt'] = CateNews::where('category_id', '1')->take(2)->get();
        foreach ($data['news_gt'] as $value) {
            $item_gt[] = $value->news_id;
        }
        $data['get_gt'] = News::whereIn('id',$item_gt)->where('status','1')->get();
        
        return view('frontend.home', $data);
    }

    //lien he
    function lienhe(){
    	return view('frontend.lienhe');
    }
    //do lien he
    function do_lienhe(Request $request){
    	$contact = new Contact();
    	$contact->name = $request->txt_name;
    	$contact->address = $request->txt_address;
    	$contact->tel = $request->txt_phone;
    	$contact->title = $request->txt_title;
    	$contact->content = $request->txt_content;
    	$contact->date = date('Y/m/d H:i:s');
    	$contact->save();
    	return redirect('lien-he')->with('success','Cám ơn bạn đã gửi liên hệ thành công');
    }

    //tim kiem
    function timkiem(){
        return view('frontend.timkiem');
    }

    //do tim kiem
    function do_timkiem(Request $request){
        $keyword = $request->txt_keyword;

        $data = News::where('title','like',"%$keyword%")->orWhere('description','like',"%$keyword%")->orWhere('content','like',"%$keyword%")->Paginate(4);
        
        return view('frontend.timkiem',['timkiem'=>$data, 'key'=>$keyword]);
    }


    //tin tuc
    function tintuc(){
        $data['tintuc'] = News::where('category_id','2')->where('status','1')->get();
        return view('frontend.tuyendung', $data);
    }

    //404
    function err404(){
        return view('errors.error404');
    }

    //dieu huong
    function xuly($cate_slug){
        $data['cate'] = Category::where('slug',$cate_slug)->first();
        
        if (!empty($data['cate'])) {
            $data['cate_id'] = $data['cate']->id;    

            $get_cate_details = CateNews::where('category_id',$data['cate_id'])->get();

            foreach ($get_cate_details as $value) {
                $item_news[] = $value->news_id;
            }
        }

        if (!empty($item_news)) {
            $data['get_news_info'] = News::whereIn('id',$item_news)->where('status','1')->paginate(4);
        }

        $data['menudoc'] = Category::where('parent',$data['cate_id'])->where('status','1')->get()->toArray();

        if ($cate_slug == 'trang-chu' || $cate_slug == 'home' || $data['cate_id'] == 13) {
            return redirect('/');
        }elseif ($cate_slug == 'lien-he' || $cate_slug == 'contact' || $data['cate_id'] == 14) {
            return redirect('lien-he');
        }else return view('frontend.tuyendung', $data);
        
    }

    //chi tiet tin tuc
    function chitiet($cate_slug, $news_slug){
        $data['cate'] = Category::where('slug',$cate_slug)->first();
        $data['cate_id'] = $data['cate']->id;
        
        $data['menudoc'] = Category::where('parent',$data['cate_id'])->get()->toArray();

        $data['hienthi'] = News::where('slug',$news_slug)->first();

        // $data['tinlq'] = News::where('category_id', $data['hienthi']->category_id)->where('id','!=',$data['hienthi']->id)->where('status','1')->take(5)->get();
        
        $data['tinlq'] = News::where('id','!=',$data['hienthi']->id)->where('status','1')->take(5)->get();

        return view('frontend.chitiettin', $data);
    }

    //dem nguoi truy cap
    function count_user(){

    }
}
