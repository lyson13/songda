<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\PageInfo;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;
class PageinfoController extends Controller
{
    function edit(){
    	$data['sua'] = PageInfo::find("1");
    	return view('admin.page-info.options', $data);
    }
    function do_edit(Request $request){
    	$page = new PageInfo();
    	$page->title = $request->txt_title;
    	$page->description = $request->txt_desc;
    	$page->email = $request->txt_email;
    	$page->address = $request->txt_address;
    	$page->tel = $request->txt_tel;
    	$page->fax = $request->txt_fax;
    	$page->save();
    	return redirect('admin/page-info')->with('nofti','Sửa thành công');
    }
}
