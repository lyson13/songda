<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Role;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class RoleController extends Controller
{
    function show(){
    	$data['hienthi'] = Role::all();
    	return view('admin.role.list', $data);
    }
    //add
    function add(){
    	return view('admin.role.options');
    }
    //do add
    function do_add(Request $request){
    	$role = new Role();
    	$role->name = $request->txt_name;
    	$role->save();
    	return redirect('admin/role/add')->with('nofti','Thêm thành công');
    }
    //edit
    function edit($id){
        $data['sua'] = Role::find($id);
    	return view('admin.role.options', $data);
    }
    //do edit
    function do_edit($id, Request $request){
        $role = Role::find($id);
        $role->name = $request->txt_name;
        $role->save();
        return redirect('admin/role/edit/'.$id)->with('nofti','Sửa thành công');
    }
    function delete($id){
        Role::destroy($id);
        return redirect('admin/role')->with('nofti','Xóa thành công');
    }
}
