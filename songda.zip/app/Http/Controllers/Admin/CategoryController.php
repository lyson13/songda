<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Category;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session, Auth;

class CategoryController extends Controller
{
    function show(){
    	$data['hienthi'] = Category::all();
    	return view('admin.category.list', $data);
    }
    function add(){
        $data['category'] = Category::all();
    	return view('admin.category.options', $data);
    }
    function do_add(Request $request){
    	$cate = new Category();
    	$cate->name = $request->txt_name;
        $cate->parent = $request->parent_category;
        $cate->status = $request->txt_status;
        $cate->description = $request->txt_desc;
        $cate->position = $request->txt_position;
        $cate->slug = str_slug($request->txt_name);
    	$cate->save();
    	return redirect('admin/category/add')->with('nofti','Thêm thành công');
    }
    function edit($id){
    	$data['sua'] = Category::find($id);
        $data['category'] = Category::all();
    	return view('admin.category.options', $data);
    }
    function do_edit($id, Request $request){
    	$cate = Category::find($id);
    	$cate->name = $request->txt_name;
        $cate->parent = $request->parent_category;
        $cate->status = $request->txt_status;
        $cate->description = $request->txt_desc;
        $cate->position = $request->txt_position;
        $cate->slug = str_slug($request->txt_name);
    	$cate->save();
    	return redirect('admin/category/edit/'.$id)->with('nofti','Sửa thành công');
    }
    function delete($id){
    	Category::destroy($id);
    	return redirect('admin/category')->with('nofti','Xóa thành công');
    }
}
