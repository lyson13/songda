<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Contact;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class ContactController extends Controller
{
    function show(){
    	$data['hienthi'] = Contact::all();
    	return view('admin.contact.list', $data);
    }
    //add
    function add(){
    	return view('admin.contact.options');
    }
    //do add
    function do_add(){

    }
    //edit
    function edit($id){
    	$data['sua'] = Contact::find($id);
    	return view('admin.contact.options', $data);
    }
    //do edit
    function do_edit($id, Request $request){
    	$contact = Contact::find($id);
    	$contact->name = $request->txt_name;
    	$contact->address = $request->txt_address;
    	$contact->tel = $request->txt_phone;
    	$contact->title = $request->txt_title;
    	$contact->content = $request->txt_content;
    	$contact->date = date('Y/m/d H:i:s');
    	$contact->save();
    	return redirect('admin/contact/edit/'.$id)->with('nofti','Sửa thông tin thành công.');
    }
    //delete
    function delete($id){
    	Contact::destroy($id);
    	return redirect('admin/contact/list')->with('nofti','Xóa thành công');
    }
}
