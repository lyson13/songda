<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Http\Request;
use App\Slide;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class SlideController extends Controller
{
    function show(){
    	$data['hienthi'] = Slide::all();
    	return view('admin.slide.list', $data);
    }
    function add(){
    	return view('admin.slide.options');
    }
    function do_add(Request $request){
    	$slide = new Slide();
    	$slide->content = $request->txt_content;
    	$slide->position = $request->txt_position;
    	$slide->status = $request->txt_stt;
    	$img = '';
    	if ($request->hasfile('txt_img')) {
    		$file_name = $request->file('txt_img');
    		$img = $file_name->getClientOriginalName();
    		$img = date("s\si\mH\hdmY")."-".$img;
    		$file_name->move("public/upload/slide/",$img);
    		$slide->images = $img;
    	}else{
    		$slide->images = $img;
    	}
    	$slide->save();
    	return redirect('admin/slide')->with('nofti','Thêm thành công');
    }
    function edit($id){
    	$data['sua'] = Slide::find($id);
    	return view('admin.slide.options', $data);
    }
    function do_edit($id, Request $request){
    	$slide = Slide::find($id);
    	$slide->content = $request->txt_content;
    	$slide->position = $request->txt_position;
    	$slide->status = $request->txt_stt;
    	$img = '';
    	if ($request->hasfile('txt_img')) {
    		$file_name = $request->file('txt_img');
    		$img = $file_name->getClientOriginalName();
    		$img = date("s\si\mH\hdmY")."-".$img;
    		$file_name->move("public/upload/slide/",$img);
    		$slide->images = $img;
    	}
    	$slide->save();
    	return redirect('admin/slide/edit/'.$id)->with('nofti','Sửa thành công');
    }
    function delete($id){
    	Slide::destroy($id);
    	return redirect('admin/slide')->with('nofti','Xóa thành công');
    }
}
