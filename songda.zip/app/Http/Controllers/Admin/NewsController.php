<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\News, App\Category, App\CateNews;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB, Session;

class NewsController extends Controller
{
    function show(){
    	$data['hienthi'] = News::all();
    	return view('admin.news.list', $data);

        $hienthi = News::all();
        return view('admin.news.list',['hienthi'=>$hienthi]);
    }

    function add(){
    	$data['all_category'] = Category::all();
    	return view('admin.news.options', $data);
    }

    function do_add(Request $request){
        $tintuc = new News();
        $tintuc->title = $request->txt_title;
        $tintuc->description = $request->txt_desc;
        $tintuc->content = $request->txt_content;
        // $tintuc->category_id = $request->parent_category;
        $tintuc->posted_date = $request->txt_date;
        $tintuc->view = 0;
        $tintuc->hot = $request->rd_hot;
        $tintuc->status = $request->rd_status;
        $img = '';
        $tintuc->slug = str_slug($request->txt_title);

        if ($request->hasFile('txt_img')) {
            $file = $request->file('txt_img');
            $img = $file->getClientOriginalName('txt_img');
            $img = date("s\si\mH\h-dmY")."-".$img;
            $file->move("public/upload/news/",$img);
            $tintuc->images = $img;
        }else{
            $tintuc->images = $img;
        }
        $tintuc->save();

        $news_id = DB::getPdo()->lastInsertId();
        foreach ($request->checkbox as $value) {
            $catenews = new CateNews();
            $catenews->category_id = $value;
            $catenews->news_id = $news_id;
            $catenews->save();
        }

        return redirect('admin/news')->with('nofti','Thêm thành công');
        
    }

    function edit($id){
        $data['sua'] = News::find($id);
        // $data['category'] = Category::where('id',$data['sua']->category_id)->first()->toArray();
        $data['all_category'] = Category::all();
        $data['news_category'] = CateNews::where('news_id',$id)->get();
    	return view('admin.news.options', $data);
    }

    function do_edit($id, Request $request){
        $tintuc = News::find($id);

        $tintuc->title = $request->txt_title;
        $tintuc->description = $request->txt_desc;
        $tintuc->content = $request->txt_content;
        // $tintuc->category_id = $request->parent_category;
        $tintuc->posted_date = $request->txt_date;
        $tintuc->view = 0;
        $tintuc->hot = $request->rd_hot;
        $tintuc->status = $request->rd_status;
        $img = '';
        $tintuc->slug = str_slug($request->txt_title);

        if ($request->hasFile('txt_img')) {
            $file = $request->file('txt_img');
            $img = $file->getClientOriginalName('txt_img');
            $img = date("s\si\mH\h-dmY")."-".$img;
            $file->move("public/upload/news/",$img);
            $tintuc->images = $img;
        }

        $tintuc->save();

        CateNews::where('news_id',$id)->delete();

        foreach ($request->checkbox as $value) {
            $new_ct = new CateNews();
            $new_ct->category_id = $value;
            $new_ct->news_id = $id;
            $new_ct->save();
        }

    	return redirect('admin/news/edit/'.$id)->with('nofti','Sửa thành công');
    }

    function delete($id){
        News::destroy($id);
        CateNews::where('news_id',$id)->delete();
    	return redirect('admin/news')->with('nofti','Xóa thành công');
    }
}
