<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\News, App\Contact, App\UserOnline;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Session;

class HomeController extends Controller
{
    function show(){
    	$data['tintuc'] = News::all();
    	$data['lienhe'] = Contact::all();
    	$data['dangonline'] = UserOnline::all();
    	return view('admin.home', $data);
    }

    function guimail(){
    	return redirect('/admin')->with('nofti','Gửi mail thành công');
    }
}
