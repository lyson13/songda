<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\User;
use App\Role;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Auth, Session, Hash;

class UserController extends Controller
{
    //show
    function show(){
        $data['hienthi'] = User::all();
        return view('admin.user.list', $data);
    }
    //add
    function add(){
        $data['quyen'] = Role::where('id','!=',1)->get();
        return view('admin.user.options', $data);
    }
    //do add
    function do_add(Request $request){
        $user = new User();
        $user->name = $request->txt_name;
        $user->email = $request->txt_email;
        $user->password = Hash::make($request->txt_password);
        $user->role_id = $request->txt_role;
        $user->save();
        return redirect('admin/user/add')->with('nofti','Thêm thành công');
    }

    //edit
    function edit($id){
        $data['sua'] = User::find($id);
        $data['quyen'] = Role::all();
        return view('admin.user.options', $data);
    }

    //do edit
    function do_edit($id, Request $request){
        $user = User::find($id);
        $user->name = $request->txt_name;
        $user->role_id = $request->txt_role;
        $password = $request->txt_password;
        if (empty($password)) {
            $user->save();
        }else{
            $user->password = Hash::make($password);
            $user->save();
        }
        return redirect('admin/user/edit/'.$id)->with('nofti','Sửa thành công');
    }

    //delete
    function delete($id){
        $role_user = User::find($id)->role_id;
        if (Auth::user()->id == $id || Auth::user()->role_id >= $role_user) {
            return redirect('admin/user')->with('nofti','Không thể xóa user.');
        }else{
            $user = new User();
            $user->destroy($id);
            return redirect('admin/user')->with('nofti','Xóa thành công');
        }
    }

	//login
    function loginAdmin(){
    	if (Auth::check()) {
    		return redirect('/admin');
    	}else return view('admin.login');
    	
    }
    //do login
    function do_loginAdmin(Request $request){
    	echo $email = $request->txt_email;
    	echo $password = $request->txt_password;
    	if (Auth::attempt(['email'=>$email, 'password'=>$password])) {
    		return redirect('/admin');
    	}else{
    		return redirect('/admin/login')->with('failed','Email hoặc Password không hợp lệ.');
    	}
    }
    //log out
    function logout(){
    	Auth::logout();
    	return redirect('admin/login');
    }
}
