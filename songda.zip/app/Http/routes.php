<?php
/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/
// Route::Controllers("auth"=>"AuthController");
Route::get('admin/login', 'Admin\UserController@loginAdmin');
Route::post('admin/login', 'Admin\UserController@do_loginAdmin');
Route::get('admin/logout', 'Admin\UserController@logout');
Route::post('send-mail', 'Admin\HomeController@guimail');
Route::group(['prefix'=>'admin', 'middleware'=>'auth'], function(){
	Route::get('/', 'Admin\HomeController@show');

	//category
	Route::group(['prefix'=>'category'],function(){
		Route::get('/', 'Admin\CategoryController@show');
		Route::get('list', 'Admin\CategoryController@show');
		Route::get('add', 'Admin\CategoryController@add');
		Route::post('add', 'Admin\CategoryController@do_add');
		Route::get('edit/{id}', 'Admin\CategoryController@edit');
		Route::post('edit/{id}', 'Admin\CategoryController@do_edit');
		Route::get('delete/{id}', 'Admin\CategoryController@delete');
	});
	//news
	Route::group(['prefix'=>'news'],function(){
		Route::get('/', 'Admin\NewsController@show');
		Route::get('list', 'Admin\NewsController@show');
		Route::get('add', 'Admin\NewsController@add');
		Route::post('add', 'Admin\NewsController@do_add');
		Route::get('edit/{id}', 'Admin\NewsController@edit');
		Route::post('edit/{id}', 'Admin\NewsController@do_edit');
		Route::get('delete/{id}', 'Admin\NewsController@delete');
	});
	//contact
	Route::group(['prefix'=>'contact'],function(){
		Route::get('/', 'Admin\ContactController@show');
		Route::get('list', 'Admin\ContactController@show');
		Route::get('add', 'Admin\ContactController@add');
		Route::post('add', 'Admin\ContactController@do_add');
		Route::get('edit/{id}', 'Admin\ContactController@edit');
		Route::post('edit/{id}', 'Admin\ContactController@do_edit');
		Route::get('delete/{id}', 'Admin\ContactController@delete');
	});
	//slide
	Route::group(['prefix'=>'slide'],function(){
		Route::get('/', 'Admin\SlideController@show');
		Route::get('list', 'Admin\SlideController@show');
		Route::get('add', 'Admin\SlideController@add');
		Route::post('add', 'Admin\SlideController@do_add');
		Route::get('edit/{id}', 'Admin\SlideController@edit');
		Route::post('edit/{id}', 'Admin\SlideController@do_edit');
		Route::get('delete/{id}', 'Admin\SlideController@delete');
	});
	//user
	Route::group(['prefix'=>'user', 'middleware'=>'user_access'],function(){
		Route::get('/', 'Admin\UserController@show');
		Route::get('list', 'Admin\UserController@show');
		Route::get('add', 'Admin\UserController@add');
		Route::post('add', 'Admin\UserController@do_add');
		Route::get('edit/{id}', 'Admin\UserController@edit');
		Route::post('edit/{id}', 'Admin\UserController@do_edit');
		Route::get('delete/{id}', 'Admin\UserController@delete');
	});
	//role
	Route::group(['prefix'=>'role','middleware'=>'role_access'],function(){
		Route::get('/', 'Admin\RoleController@show');
		Route::get('list', 'Admin\RoleController@show');
		Route::get('add', 'Admin\RoleController@add');
		Route::post('add', 'Admin\RoleController@do_add');
		Route::get('edit/{id}', 'Admin\RoleController@edit');
		Route::post('edit/{id}', 'Admin\RoleController@do_edit');
		Route::get('delete/{id}', 'Admin\RoleController@delete');
	});
	//page info
	Route::get('page-info','Admin\PageinfoController@edit');
	Route::post('page-info','Admin\PageinfoController@do_edit');

});
//- - - - - - FRONTEND - - - - - -
Route::get('/', 'Frontend\FrontendController@home');
// Route::get('trang-chu', 'Frontend\FrontendController@home');
Route::get('tim-kiem','Frontend\FrontendController@timkiem');
Route::get('lien-he', 'Frontend\FrontendController@lienhe');
Route::get('{cate_slug}','Frontend\FrontendController@xuly');

Route::get('{cate_slug}/{news_slug}', 'Frontend\FrontendController@chitiet');

//post
Route::post('lien-he','Frontend\FrontendController@do_lienhe');
Route::post('tim-kiem', 'Frontend\FrontendController@do_timkiem');

//- - - - - - END FRONTEND - - - - - -
//404
Route::get("404", 'Frontend\FrontendController@err404');

Route::get('online','Frontend\FrontendController@count_user');